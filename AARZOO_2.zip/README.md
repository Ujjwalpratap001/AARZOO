# AARZOO

Student planner: Home dashboard, My Day timeline, Habit Matrix, Notes Vault, Focus Stream, Exam Planner, Control Center.
Built with plain HTML/CSS/JS wrapped by Capacitor 6 (Android). All data is stored on the phone (IndexedDB).

## Get the APK from GitHub
1. Create a new GitHub repository and upload everything in this folder (the files, not the zip itself). Keep the `.github` folder.
2. Open the repo, go to the **Actions** tab, and wait for **Build AARZOO APK** to finish (about 5 to 8 minutes). Use **Run workflow** if it does not start by itself.
3. Open the finished run, download the **AARZOO-apk** artifact, unzip it, and install `app-debug.apk` on your phone.

## What works on-device
Tasks, deadlines with live countdown, sticky notes, habits and streaks, notes with rich text, file uploads, focus rooms and a timestamp-based timer, a rule-based exam plan generator, analytics, search, reminders (Android local notifications), data export, light/dark theme.

## Needs a backend (not faked)
Friend requests, friend search, messaging, live sharing with permissions, Google Sign-In and a real AI model for exam plans.
Accounts here are local to the device. These screens say so plainly.
