'use strict';
const FICONS = ['folder', '📘', '🧪', '💻', '🧬', '⚛️', '📐', '🩺', '🎨', '📊'];
const fIcon = f => f.icon && f.icon !== 'folder' ? f.icon : ic('folder', 24);
const nPreview = n => { const t = txt(n.html).trim(); return t.length > 110 ? t.slice(0, 110) + '...' : t; };
const bytes = b => b < 1024 ? b + ' B' : b < 1048576 ? (b / 1024).toFixed(1) + ' KB' : (b / 1048576).toFixed(1) + ' MB';
const fCount = f => D.notes.filter(n => n.folderId === f.id).length + D.files.filter(x => x.folderId === f.id).length;

function clean(html) {
  const root = new DOMParser().parseFromString('<div>' + html + '</div>', 'text/html').body.firstChild;
  const ok = new Set(['B', 'I', 'U', 'STRONG', 'EM', 'UL', 'OL', 'LI', 'H2', 'H3', 'A', 'BR', 'DIV', 'P', 'SPAN', 'STRIKE', 'FONT']);
  (function walk(n) {
    [...n.children].forEach(c => {
      if (!ok.has(c.tagName)) { while (c.firstChild) n.insertBefore(c.firstChild, c); c.remove(); return; }
      [...c.attributes].forEach(a => { if (!(c.tagName === 'A' && a.name === 'href')) c.removeAttribute(a.name); });
      if (c.tagName === 'A' && !/^(https?:|mailto:)/i.test(c.getAttribute('href') || '')) c.removeAttribute('href');
      walk(c);
    });
  })(root);
  return root.innerHTML;
}

/* ---------- vault home ---------- */
SCREENS.vault = () => `${hdr('Notes Vault', 'Manage your subjects', `<button class="ib big" data-a="exportall">${ic('share')}</button><button class="ib big" data-a="go" data-to="push:friends">${ic('users')}</button>`)}
<div class="search">${ic('search')}<input id="vq" placeholder="Search folders, notes, files" value="${esc(R.vq || '')}"></div><div id="vres">${vres(R.vq || '')}</div><button class="fab" data-a="addfolder">${ic('plus', 28)}</button>`;
const fcard = f => `<button class="fcard" style="--c:${f.color}" data-a="go" data-to="push:folder" data-p="${gop({ id: f.id })}"><div class="row between" style="align-items:flex-start"><i>${fIcon(f)}</i>${f.pinned ? `<span style="color:var(--acc)">${ic('pin', 16)}</span>` : ''}</div><div><b>${esc(f.name)}</b><small style="display:block;margin-top:4px">${fCount(f)} item${fCount(f) === 1 ? '' : 's'}</small></div></button>`;
function vres(q) {
  q = q.trim().toLowerCase();
  let fs = D.folders.slice().sort((a, b) => (b.pinned - a.pinned) || a.name.localeCompare(b.name));
  const noteHits = q ? D.notes.filter(n => n.title.toLowerCase().includes(q) || txt(n.html).toLowerCase().includes(q)) : [];
  const fileHits = q ? D.files.filter(f => f.name.toLowerCase().includes(q)) : [];
  if (q) fs = fs.filter(f => [f.name, f.subject, f.desc].some(x => (x || '').toLowerCase().includes(q)));
  let h = fs.length ? `<div class="fgrid">${fs.map(fcard).join('')}</div>` : (q ? '' : empty('No folders yet', 'Tap + to create a folder for a subject.', 'folder'));
  if (q && noteHits.length) h += `<div class="cap">NOTES</div>${noteHits.map(noteRow).join('')}`;
  if (q && fileHits.length) h += `<div class="cap">FILES</div>${fileHits.map(fileRow).join('')}`;
  if (q && !fs.length && !noteHits.length && !fileHits.length) h = empty('No matches', 'Try different words.', 'search');
  return h;
}
A.exportall = () => {
  if (!D.notes.length) return toast('No notes to share yet', true);
  shareText('AARZOO notes', D.folders.map(f => '# ' + f.name + '\n' + D.notes.filter(n => n.folderId === f.id).map(n => '## ' + n.title + '\n' + txt(n.html)).join('\n\n')).join('\n\n'));
};
A.addfolder = () => folderForm(null);
function folderForm(f) {
  const e = f || { color: '#F52C79', icon: 'folder' };
  formSheet(f ? 'Edit folder' : 'New folder', F.t('Folder name *', 'name', e.name, 'e.g. Data Structures') + F.a('Description', 'desc', e.desc) + F.t('Subject / category', 'subject', e.subject) + F.s('Icon', 'icon', FICONS.map(i => [i, i === 'folder' ? 'Folder' : i]), e.icon) + F.col('color', e.color),
    v => {
      const name = v.name.trim(); if (!name) return 'Folder name is required.';
      if (D.folders.some(x => x !== f && x.name.toLowerCase() === name.toLowerCase())) return 'A folder with this name already exists.';
      const o = { name, desc: v.desc.trim(), subject: v.subject.trim(), icon: v.icon, color: v.color };
      if (f) Object.assign(f, o); else D.folders.push({ id: uid(), pinned: false, created: Date.now(), ...o });
      save(); closeSheet(); toast(f ? 'Folder updated' : 'Folder created'); render(true);
    });
}
function delFolder(f) {
  const n = fCount(f);
  confirmBox('Delete "' + f.name + '"?', n ? 'This permanently deletes ' + n + ' note/file item' + (n === 1 ? '' : 's') + ' inside it.' : 'This folder is empty.', async () => {
    for (const x of D.files.filter(x => x.folderId === f.id)) { try { await DBW.del('files', x.id); } catch (e) { } }
    D.files = D.files.filter(x => x.folderId !== f.id); D.notes = D.notes.filter(x => x.folderId !== f.id); D.folders = D.folders.filter(x => x.id !== f.id);
    save(); R.stack = []; render(); toast('Folder deleted');
  });
}

/* ---------- folder screen ---------- */
const noteRow = n => `<button class="li" style="--c:${n.color || '#258BFF'}" data-a="go" data-to="push:note" data-p="${gop({ id: n.id })}"><div class="grow"><b>${esc(n.title)}</b><small>${esc(nPreview(n)) || 'Empty note'}</small><small>${new Date(n.updated).toLocaleDateString([], { month: 'short', day: 'numeric' })}${(() => { const f = D.folders.find(x => x.id === n.folderId); return f ? ' · ' + esc(f.name) : ''; })()}</small></div></button>`;
const fileRow = f => `<button class="li" data-a="openfile" data-id="${f.id}"><i>${ic('file', 20)}</i><div class="grow"><b>${esc(f.name)}</b><small>${bytes(f.size)} · ${new Date(f.added).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}</small></div></button>`;
SCREENS.folder = p => {
  const f = D.folders.find(x => x.id === p.id); if (!f) return hdr('Folder') + empty('Folder not found', '', 'folder');
  return `${hdr(esc(f.name), esc(f.desc || f.subject || ''), `<button class="ib" data-a="fpin" data-id="${f.id}" style="${f.pinned ? '' : 'color:var(--mut)'}">${ic('pin', 18)}</button><button class="ib" data-a="fshare" data-id="${f.id}">${ic('share', 18)}</button><button class="ib" data-a="fedit" data-id="${f.id}">${ic('edit', 18)}</button><button class="ib red" data-a="fdel2" data-id="${f.id}">${ic('trash', 18)}</button>`)}
  <div class="search">${ic('search')}<input id="fq" placeholder="Search in this folder" value="${esc(R.fq || '')}"></div>
  <div class="two" style="margin-bottom:16px"><button class="btn pri" data-a="go" data-to="push:note" data-p="${gop({ folderId: f.id })}">${ic('plus', 18)} Add note</button><button class="btn" data-a="upload" data-id="${f.id}">${ic('upload', 18)} Upload file</button></div>
  <div id="fres">${fres(f, R.fq || '')}</div>`;
};
function fres(f, q) {
  q = q.trim().toLowerCase();
  const ns = D.notes.filter(n => n.folderId === f.id && (!q || n.title.toLowerCase().includes(q) || txt(n.html).toLowerCase().includes(q))).sort((a, b) => b.updated - a.updated);
  const fl = D.files.filter(x => x.folderId === f.id && (!q || x.name.toLowerCase().includes(q))).sort((a, b) => b.added - a.added);
  if (!ns.length && !fl.length) return empty(q ? 'No matches' : 'This folder is empty', q ? '' : 'Add a note or upload a file.', 'folder');
  return (ns.length ? `<div class="cap" style="margin-top:0">NOTES</div>${ns.map(noteRow).join('')}` : '') + (fl.length ? `<div class="cap">FILES</div>${fl.map(fileRow).join('')}` : '');
}
A.fpin = el => { const f = D.folders.find(x => x.id === el.dataset.id); f.pinned = !f.pinned; save(); render(true); toast(f.pinned ? 'Folder pinned' : 'Folder unpinned'); };
A.fedit = el => folderForm(D.folders.find(x => x.id === el.dataset.id));
A.fdel2 = el => delFolder(D.folders.find(x => x.id === el.dataset.id));
A.fshare = el => {
  const f = D.folders.find(x => x.id === el.dataset.id), ns = D.notes.filter(n => n.folderId === f.id);
  if (!ns.length) return toast('Add a note first, then share the folder', true);
  shareText(f.name, '# ' + f.name + '\n\n' + ns.map(n => '## ' + n.title + '\n' + txt(n.html)).join('\n\n'));
};

/* ---------- note editor ---------- */
let _sel = null;
document.addEventListener('selectionchange', () => { const ed = $('#ned'), s = getSelection(); if (ed && s.rangeCount && ed.contains(s.anchorNode)) _sel = s.getRangeAt(0).cloneRange(); });
SCREENS.note = p => {
  const n = p.id ? D.notes.find(x => x.id === p.id) : null;
  R.nctx = { id: n ? n.id : null, folderId: n ? n.folderId : p.folderId };
  const tb = [['bold', 'B'], ['italic', 'I'], ['underline', 'U'], ['formatBlock', 'H', 'H2'], ['insertUnorderedList', '•'], ['insertOrderedList', '1.'], ['createLink', 'Link'], ['removeFormat', 'Clear']];
  return `${hdr(n ? 'Edit note' : 'New note', '', `<button class="btn pri sm" data-a="savenote">Save</button>${n ? `<button class="ib red" data-a="delnote">${ic('trash', 18)}</button>` : ''}`)}
  <input class="inp big" id="ntitle" placeholder="Title" value="${esc(n ? n.title : '')}">
  <div class="tbar">${tb.map(b => `<button data-a="fmt" data-cmd="${b[0]}" data-val="${b[2] || ''}" style="${b[1] === 'B' ? 'font-weight:900' : b[1] === 'I' ? 'font-style:italic' : b[1] === 'U' ? 'text-decoration:underline' : ''}">${b[1]}</button>`).join('')}</div>
  <div id="ned" class="ned" contenteditable="true" data-ph="Start writing...">${n ? n.html : ''}</div>
  <div id="nform">${F.col('ncolor', n ? n.color || '#258BFF' : '#258BFF', PAL, 'Note color')}</div>`;
};
AFTER.note = () => { R.leave = () => saveNote(true); };
A.fmt = el => {
  const ed = $('#ned'); if (!ed) return; ed.focus();
  if (_sel) { const s = getSelection(); s.removeAllRanges(); s.addRange(_sel); }
  let cmd = el.dataset.cmd, val = el.dataset.val || null;
  if (cmd === 'createLink') { val = prompt('Enter link address (https://...)'); if (!val) return; if (!/^(https?:|mailto:)/i.test(val)) val = 'https://' + val; }
  if (cmd === 'formatBlock') { const cur = document.queryCommandValue('formatBlock'); val = /h2/i.test(cur) ? 'DIV' : 'H2'; }
  document.execCommand(cmd, false, val);
};
function saveNote(silent) {
  const ctx = R.nctx, title = ($('#ntitle').value || '').trim(), html = clean($('#ned').innerHTML), color = ($('#nform input[name=ncolor]') || {}).value;
  if (!title && !txt(html).trim()) { if (!silent) toast('Write a title or some text first', true); return false; }
  const ex = ctx.id ? D.notes.find(x => x.id === ctx.id) : null;
  if (ex) { if (ex.title === (title || 'Untitled') && ex.html === html && ex.color === color) return true; Object.assign(ex, { title: title || 'Untitled', html, color, updated: Date.now() }); }
  else { const n = { id: uid(), folderId: ctx.folderId, title: title || 'Untitled', html, color, created: Date.now(), updated: Date.now() }; D.notes.push(n); ctx.id = n.id; }
  save(); if (silent) toast('Note saved'); return true;
}
A.savenote = () => { if (saveNote(false)) { R.leave = null; toast('Note saved'); pop(); } };
A.delnote = () => confirmBox('Delete note?', 'This cannot be undone.', () => { D.notes = D.notes.filter(x => x.id !== R.nctx.id); R.leave = null; save(); pop(); toast('Note deleted'); });

/* ---------- files ---------- */
A.upload = el => { R.upFolder = el.dataset.id; $('#fileIn').click(); };
$('#fileIn').addEventListener('change', async e => {
  const files = [...e.target.files]; e.target.value = ''; if (!files.length || !D) return;
  let ok = 0;
  for (const f of files) {
    if (f.size > 30 * 1048576) { toast(f.name + ' is larger than 30 MB', true); continue; }
    try { const id = uid(); await DBW.set('files', id, f); D.files.push({ id, folderId: R.upFolder, name: f.name, size: f.size, type: f.type || 'application/octet-stream', added: Date.now() }); ok++; }
    catch (err) { toast('Could not save ' + f.name, true); }
  }
  if (ok) { save(); toast(ok + ' file' + (ok > 1 ? 's' : '') + ' uploaded'); render(true); }
});
A.openfile = async el => {
  const f = D.files.find(x => x.id === el.dataset.id); if (!f) return;
  let blob = null; try { blob = await DBW.get('files', f.id); } catch (e) { }
  if (!blob) return toast('This file is missing from storage', true);
  const img = f.type.startsWith('image/') ? `<img class="vimg" src="${URL.createObjectURL(blob)}" alt="">` : '';
  infoSheet(f.name, img + kv('Type', esc(f.type)) + kv('Size', bytes(f.size)) + kv('Uploaded', new Date(f.added).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })),
    `<button class="ib red" data-a="fdelf" data-id="${f.id}">${ic('trash', 20)}</button><button class="btn pri" data-a="fsend" data-id="${f.id}">${ic('download', 18)} Open / Save / Share</button>`);
};
A.fsend = async el => { const f = D.files.find(x => x.id === el.dataset.id); const b = await DBW.get('files', f.id); if (b) shareBlob(b, f.name); };
A.fdelf = el => confirmBox('Delete file?', 'This cannot be undone.', async () => { const id = el.dataset.id; try { await DBW.del('files', id); } catch (e) { } D.files = D.files.filter(x => x.id !== id); save(); closeSheet(); render(true); toast('File deleted'); });
