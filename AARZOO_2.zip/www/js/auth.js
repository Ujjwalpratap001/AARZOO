'use strict';
const OB = [
  ['cal', 'Plan your day', 'A timeline for every task, class and break, with reminders that actually reach you.'],
  ['bolt', 'Track your habits', 'Tick habits off in a monthly matrix and watch your streaks grow.'],
  ['folder', 'Organize your notes', 'Subject folders with rich notes and files, all searchable.'],
  ['target', 'Focus without distractions', 'Schedule deep-work rooms and time real study sessions.'],
  ['cpu', 'Prepare for exams', 'Turn your syllabus into a day-by-day study timeline and matrix.'],
  ['bars', 'Track your productivity', 'Daily, weekly and monthly insights from what you actually did.']
];
const authWrap = inner => `<div class="auth">${inner}</div>`;

function renderAuth() {
  const s = R.auth, app = $('#app'); closeAll();
  if (s === 'splash') { app.innerHTML = `<div class="center"><div class="logo big">AARZOO</div><p class="mut">Plan. Focus. Achieve.</p></div>`; return; }
  if (s === 'onboard') {
    const o = OB[R.ob];
    app.innerHTML = `<div class="center"><div class="ob-i">${ic(o[0], 56)}</div><h1>${o[1]}</h1><p class="mut" style="max-width:300px;line-height:1.5">${o[2]}</p><div class="dots">${OB.map((_, i) => `<i class="${i === R.ob ? 'on' : ''}"></i>`).join('')}</div>
      <button class="btn pri full" data-a="obnext" style="max-width:320px">${R.ob === OB.length - 1 ? 'Get started' : 'Next'}</button>${R.ob < OB.length - 1 ? '<button class="link" data-a="obskip" style="padding:10px">Skip</button>' : ''}</div>`;
    return;
  }
  if (s === 'login') {
    app.innerHTML = authWrap(`<div class="logo">AARZOO</div><h1>Welcome back</h1><p class="mut">Log in to your planner.</p><div id="authf" style="margin-top:22px">${F.t('Email', 'email', '', 'you@example.com', 'type="email" autocomplete="email"')}${F.t('Password', 'pw', '', 'Your password', 'type="password" autocomplete="current-password"')}<div class="err" id="ferr"></div></div>
      <button class="btn pri full" data-a="dologin" id="abtn">Log in</button><div class="row between" style="margin-top:16px"><button class="link" data-a="authgo" data-to="forgot">Forgot password?</button><button class="link" data-a="authgo" data-to="signup">Create account</button></div>`);
    return;
  }
  if (s === 'signup') {
    app.innerHTML = authWrap(`<div class="logo">AARZOO</div><h1>Create account</h1><p class="mut">Your data stays private to your account on this device.</p><div id="authf" style="margin-top:22px">${F.t('Full name', 'name', '', 'Your name', 'autocomplete="name"')}${F.t('Email', 'email', '', 'you@example.com', 'type="email"')}${F.t('Password (min 6 characters)', 'pw', '', '', 'type="password" autocomplete="new-password"')}<div class="err" id="ferr"></div></div>
      <button class="btn pri full" data-a="dosignup" id="abtn">Sign up</button><div class="row" style="margin-top:16px;justify-content:center"><span class="mut">Already have an account?</span><button class="link" data-a="authgo" data-to="login">Log in</button></div>`);
    return;
  }
  if (s === 'forgot') {
    app.innerHTML = authWrap(`<div class="logo">AARZOO</div><h1>Reset password</h1><p class="mut">Accounts live on this device, so you can set a new password here without an email link.</p><div id="authf" style="margin-top:22px">${F.t('Account email', 'email', '', 'you@example.com', 'type="email"')}${F.t('New password (min 6 characters)', 'pw', '', '', 'type="password"')}<div class="err" id="ferr"></div></div>
      <button class="btn pri full" data-a="doforgot" id="abtn">Set new password</button><div class="row" style="margin-top:16px;justify-content:center"><button class="link" data-a="authgo" data-to="login">Back to log in</button></div>`);
    return;
  }
  if (s === 'setup') {
    const p = D.profile;
    app.innerHTML = authWrap(`<h1>Set up your profile</h1><p class="mut">All optional. You can finish this later in Profile.</p><div id="authf" style="margin-top:22px">${F.t('College / university', 'college', p.college)}${F.t('Course', 'course', p.course, 'e.g. B.Tech CSE')}${F.t('Semester / year', 'semester', p.semester, 'e.g. 3rd semester')}${F.t('Subjects (comma separated)', 'subjects', p.subjects, 'DSA, DBMS, OS')}${F.a('Study preferences', 'pref', p.pref, 'e.g. I study best at night')}</div>
      <button class="btn pri full" data-a="dosetup">Save and continue</button><button class="btn full" data-a="skipsetup" style="margin-top:10px">Skip for now</button>`);
  }
}
A.authgo = el => { R.auth = el.dataset.to; renderAuth(); };
A.obnext = () => { if (R.ob < OB.length - 1) { R.ob++; renderAuth(); } else A.obskip(); };
A.obskip = () => { localStorage.setItem('aarzoo_onb', '1'); R.auth = 'signup'; renderAuth(); };
const emailOk = e => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);
const busy = (on) => { const b = $('#abtn'); if (b) { b.disabled = on; } };
const authErr = m => { $('#ferr').textContent = m; busy(false); };

A.dosignup = async () => {
  const v = formVals($('#authf')), name = v.name.trim(), email = v.email.trim().toLowerCase();
  if (!name) return authErr('Enter your name.');
  if (!emailOk(email)) return authErr('Enter a valid email address.');
  if (v.pw.length < 6) return authErr('Password must be at least 6 characters.');
  busy(true);
  const users = await Acc.users();
  if (users.some(u => u.email === email)) return authErr('An account with this email already exists. Log in instead.');
  const u = { id: uid(), name, email, hash: await Acc.hash(v.pw), pubId: Acc.pubId(users), created: Date.now() };
  users.push(u); await Acc.saveUsers(users);
  await loadUser(u); flush(); R.sel = today(); R.auth = 'setup'; renderAuth();
};
A.dologin = async () => {
  const v = formVals($('#authf')), email = v.email.trim().toLowerCase();
  if (!emailOk(email) || !v.pw) return authErr('Enter your email and password.');
  busy(true);
  const u = (await Acc.users()).find(x => x.email === email);
  if (!u || u.hash !== await Acc.hash(v.pw)) return authErr('Email or password is incorrect.');
  await loadUser(u); R.sel = today(); startApp();
};
A.doforgot = async () => {
  const v = formVals($('#authf')), email = v.email.trim().toLowerCase();
  if (!emailOk(email)) return authErr('Enter a valid email address.');
  if (v.pw.length < 6) return authErr('Password must be at least 6 characters.');
  busy(true);
  const users = await Acc.users(), u = users.find(x => x.email === email);
  if (!u) return authErr('No account found with this email on this device.');
  u.hash = await Acc.hash(v.pw); await Acc.saveUsers(users);
  R.auth = 'login'; renderAuth(); toast('Password updated. Log in with your new password.');
};
A.dosetup = () => {
  const v = formVals($('#authf')); Object.assign(D.profile, { college: v.college.trim(), course: v.course.trim(), semester: v.semester.trim(), subjects: v.subjects.trim(), pref: v.pref.trim() });
  flush(); startApp();
};
A.skipsetup = () => startApp();

function applyTheme() {
  document.documentElement.dataset.theme = D ? D.prefs.theme : 'dark';
  document.documentElement.style.setProperty('--acc', D ? D.prefs.accent : '#08D9F2');
  const sb = cap('StatusBar');
  if (sb && isNative()) { try { sb.setBackgroundColor({ color: D && D.prefs.theme === 'light' ? '#f3f5f9' : '#000000' }); sb.setStyle({ style: D && D.prefs.theme === 'light' ? 'LIGHT' : 'DARK' }); } catch (e) { } }
}
async function startApp() {
  R.auth = null; R.tab = 'home'; R.stack = []; R.leave = null;
  applyTheme(); render();
  const LN = cap('LocalNotifications');
  if (LN && isNative() && !localStorage.getItem('aarzoo_np')) { localStorage.setItem('aarzoo_np', '1'); try { await LN.requestPermissions(); } catch (e) { } }
  scheduleAll(); checkReminders();
}
A.logout = () => confirmBox('Log out?', 'Your data stays saved on this device.', () => {
  flush(); localStorage.removeItem('aarzoo_uid'); D = null; USER = null; R.auth = 'login'; R.stack = []; renderAuth();
}, 'Log out');
