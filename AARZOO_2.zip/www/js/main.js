'use strict';
/* live search boxes: update only the results area so the keyboard stays open */
document.addEventListener('input', e => {
  const t = e.target, id = t.id;
  if (id === 'vq') { R.vq = t.value; $('#vres').innerHTML = vres(t.value); }
  else if (id === 'fq') { R.fq = t.value; const f = D.folders.find(x => x.id === curScreen().p.id); if (f) $('#fres').innerHTML = fres(f, t.value); }
  else if (id === 'gq') { R.gq = t.value; $('#gres').innerHTML = gres(t.value); }
  else if (id === 'sq') { R.sq = t.value; $('#sres').innerHTML = stRes(t.value); }
  else if (t.name === 'start' || t.name === 'end' || t.name === 'dur') {
    const f = $('#frm'); if (!f) return;
    const s = $('[name=start]', f), en = $('[name=end]', f), d = $('[name=dur]', f); if (!s || !en || !d) return;
    if (t.name === 'dur') { const m = +d.value; if (validTime(s.value) && m > 0 && mins(s.value) + m < 1440) en.value = hm(mins(s.value) + m); }
    else if (validTime(s.value) && validTime(en.value) && mins(en.value) > mins(s.value)) d.value = mins(en.value) - mins(s.value);
  }
});

/* one-second heartbeat: countdowns, running timer */
setInterval(() => {
  if (!D) return;
  $$('[data-cdid]').forEach(el => {
    const x = D.deadlines.find(d => d.id === el.dataset.cdid); if (!x) return;
    const c = cdParts(x); el.classList.toggle('over', c.over);
    $('.cdn', el).textContent = cdTxt(c); $('.cdl', el).textContent = c.over ? 'OVERDUE' : 'DAYS HRS MIN';
  });
  timerTick();
}, 1000);
/* reminders + gentle refresh of time-based states */
setInterval(() => { if (D) checkReminders(); }, 30000);

document.addEventListener('visibilitychange', () => { if (document.hidden) flush(); else if (D) { checkReminders(); timerTick(); render(true); scheduleSoon(); } });
window.addEventListener('pagehide', flush);

function capSetup() {
  const app = cap('App');
  if (app) {
    app.addListener('backButton', () => { if (!pop()) app.exitApp(); });
    app.addListener('appStateChange', s => { if (!s.isActive) flush(); else if (D) { timerTick(); checkReminders(); } });
  }
  const sb = cap('StatusBar'); if (sb && isNative()) { try { sb.setOverlaysWebView({ overlay: false }); } catch (e) { } }
}
/* browser fallback for the back gesture */
if (!window.Capacitor || !window.Capacitor.isNativePlatform || !window.Capacitor.isNativePlatform()) { history.pushState({}, ''); window.addEventListener('popstate', () => { history.pushState({}, ''); pop(); }); }

async function boot() {
  capSetup();
  try { await DBW.open(); } catch (e) { $('#app').innerHTML = '<div class="center"><h2>Storage unavailable</h2><p class="mut">AARZOO needs browser storage to save your data.</p></div>'; return; }
  const id = localStorage.getItem('aarzoo_uid');
  if (id) { const u = (await Acc.users()).find(x => x.id === id); if (u) { await loadUser(u); R.sel = today(); startApp(); return; } }
  R.auth = 'splash'; renderAuth();
  setTimeout(async () => {
    const users = await Acc.users();
    R.auth = localStorage.getItem('aarzoo_onb') ? (users.length ? 'login' : 'signup') : 'onboard'; renderAuth();
  }, 1200);
}
boot();
