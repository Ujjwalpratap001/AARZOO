'use strict';
/* ---------- tiny helpers ---------- */
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pad = n => String(n).padStart(2, '0');
const ymd = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
const pd = s => { const a = s.split('-').map(Number); return new Date(a[0], a[1] - 1, a[2]); };
const addDays = (s, n) => { const d = pd(s); d.setDate(d.getDate() + n); return ymd(d); };
const today = () => ymd(new Date());
const mins = t => { const a = t.split(':').map(Number); return a[0] * 60 + a[1]; };
const hm = m => pad(Math.floor(m / 60)) + ':' + pad(m % 60);
const fmtT = t => t ? new Date(2000, 0, 1, ...t.split(':').map(Number)).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) : '';
const fmtD = (s, o) => pd(s).toLocaleDateString([], o || { month: 'short', day: 'numeric' });
const dur = m => { m = Math.round(m); const h = Math.floor(m / 60), r = m % 60; return h && r ? h + 'h ' + r + 'm' : h ? h + 'h' : r + 'm'; };
const dow = s => pd(s).getDay();
const validDate = s => /^\d{4}-\d{2}-\d{2}$/.test(s || '') && ymd(pd(s)) === s;
const validTime = s => /^\d{2}:\d{2}$/.test(s || '');
const txt = h => { const d = document.createElement('div'); d.innerHTML = h || ''; return d.textContent || ''; };
const h32 = s => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 1) % 2147483000 + 1; };
const first = n => (n || '').trim().split(/\s+/)[0] || 'there';

/* ---------- IndexedDB (persistent storage) ---------- */
const DBW = {
  db: null,
  open() {
    return new Promise((ok, no) => {
      const r = indexedDB.open('aarzoo', 1);
      r.onupgradeneeded = () => { r.result.createObjectStore('kv'); r.result.createObjectStore('files'); };
      r.onsuccess = () => { this.db = r.result; ok(); };
      r.onerror = () => no(r.error);
    });
  },
  tx(st, mode, fn) {
    return new Promise((ok, no) => {
      const t = this.db.transaction(st, mode);
      const q = fn(t.objectStore(st));
      t.oncomplete = () => ok(q && q.result);
      t.onerror = () => no(t.error);
      t.onabort = () => no(t.error);
    });
  },
  get(st, k) { return this.tx(st, 'readonly', s => s.get(k)); },
  set(st, k, v) { return this.tx(st, 'readwrite', s => s.put(v, k)); },
  del(st, k) { return this.tx(st, 'readwrite', s => s.delete(k)); }
};

/* ---------- accounts (stored on this device) ---------- */
const TPREF = { face: 'ring', size: 72, thick: 8, glow: 50, font: 'sans', textSize: 44, weight: 700, label: 'Deep work', align: 'center', bg: '#000000', ring: '#08D9F2', text: '#08D9F2', anim: 50, preset: 'classic', vpos: 'center', gap: 10 };
const emptyData = (name, email) => ({
  v: 1,
  profile: { name: name || '', email: email || '', college: '', course: '', semester: '', bio: '', photo: '', subjects: '', pref: '' },
  tasks: [], deadlines: [], stickies: [], habits: [], habitLog: {}, folders: [], notes: [], files: [],
  rooms: [], sessions: [], exams: [], plan: [], planCfg: { start: '18:00', unavail: [] }, planInDay: false,
  notifs: [], fired: {}, timerState: null,
  prefs: { theme: 'dark', accent: '#08D9F2', timer: { ...TPREF }, notif: { tasks: true, deadlines: true, habits: true, focus: true, exams: true } }
});
let D = null, USER = null;

const Acc = {
  async users() { return (await DBW.get('kv', 'users')) || []; },
  async saveUsers(u) { await DBW.set('kv', 'users', u); },
  async hash(p) {
    try {
      const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('aarzoo:' + p));
      return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('');
    } catch (e) { let h = 5381; for (const c of 'aarzoo:' + p) h = ((h << 5) + h + c.charCodeAt(0)) | 0; return 'x' + h; }
  },
  pubId(users) { let id; do { id = String(Math.floor(1000000 + Math.random() * 9000000)); } while (users.some(u => u.pubId === id)); return id; }
};

async function loadUser(u) {
  USER = u;
  const saved = (await DBW.get('kv', 'data:' + u.id)) || {};
  const base = emptyData(u.name, u.email);
  D = { ...base, ...saved, profile: { ...base.profile, ...(saved.profile || {}) } };
  D.prefs = { ...base.prefs, ...(saved.prefs || {}) };
  D.prefs.timer = { ...TPREF, ...(D.prefs.timer || {}) };
  D.prefs.notif = { ...base.prefs.notif, ...(D.prefs.notif || {}) };
  D.planCfg = { ...base.planCfg, ...(D.planCfg || {}) };
  localStorage.setItem('aarzoo_uid', u.id);
}
let _st = null;
const save = () => { clearTimeout(_st); _st = setTimeout(flush, 120); };
function flush() { clearTimeout(_st); if (D && USER) DBW.set('kv', 'data:' + USER.id, D).catch(() => { }); }

/* ---------- schedule logic ---------- */
function occurs(it, d) {
  if (!it.date || d < it.date) return false;
  const r = it.repeat || 'none';
  if (r === 'none') return d === it.date;
  if (r === 'daily') return true;
  if (r === 'weekly') return dow(d) === dow(it.date);
  if (r === 'custom') return (it.repeatDays || []).includes(dow(d));
  return false;
}
function tasksOn(d) {
  const out = [];
  D.tasks.forEach(t => { if (occurs(t, d)) out.push({ ...t, occ: d, isDone: !!(t.doneDates || {})[d] }); });
  if (D.planInDay) {
    D.plan.filter(s => s.date === d).forEach(s => {
      const ex = D.exams.find(e => e.id === s.examId), tp = ex && ex.topics.find(x => x.id === s.topicId);
      out.push({ id: 'ps_' + s.id, planId: s.id, source: 'exam', title: (s.type === 'revision' ? 'Revise: ' : 'Study: ') + (ex ? ex.subject : '') + ' - ' + (tp ? tp.name : ''), start: s.start, end: s.end, color: '#8B36F5', priority: 'medium', occ: d, isDone: !!s.done, subject: ex ? ex.subject : '' });
    });
  }
  return out.sort((a, b) => mins(a.start) - mins(b.start));
}
function tstatus(t) {
  if (t.isDone) return 'done';
  const n = new Date(), td = ymd(n);
  if (t.occ < td) return 'overdue';
  if (t.occ > td) return 'pending';
  const m = n.getHours() * 60 + n.getMinutes();
  if (m >= mins(t.end)) return 'overdue';
  if (m >= mins(t.start)) return 'active';
  return 'pending';
}
function toggleTask(t) {
  if (t.planId) {
    const s = D.plan.find(x => x.id === t.planId); if (!s) return;
    s.done = !s.done;
    const ex = D.exams.find(e => e.id === s.examId), tp = ex && ex.topics.find(x => x.id === s.topicId);
    if (tp) { if (s.type === 'revision') tp.revised = s.done; else tp.done = s.done; }
  } else {
    const rt = D.tasks.find(x => x.id === t.id); if (!rt) return;
    rt.doneDates = rt.doneDates || {};
    if (rt.doneDates[t.occ]) { delete rt.doneDates[t.occ]; hist(rt, 'Marked incomplete (' + t.occ + ')'); }
    else { rt.doneDates[t.occ] = Date.now(); hist(rt, 'Completed (' + t.occ + ')'); }
  }
  save();
}
function hist(t, act) { t.history = t.history || []; t.history.push({ at: Date.now(), act }); if (t.history.length > 30) t.history.shift(); }

/* ---------- habits ---------- */
function sched(h, d) { return d >= h.start && (h.freq !== 'custom' || (h.days || []).includes(dow(d))); }
function habitsOn(d) { return D.habits.filter(h => !h.paused && sched(h, d)); }
function streak(h) {
  const log = D.habitLog[h.id] || {}, t = today();
  let cur = 0, d = t;
  for (let i = 0; i < 4000 && d >= h.start; i++) {
    if (sched(h, d)) { if (log[d]) cur++; else if (d !== t) break; }
    d = addDays(d, -1);
  }
  let best = 0, run = 0;
  for (let x = h.start; x <= t; x = addDays(x, 1)) { if (!sched(h, x)) continue; if (log[x]) { run++; if (run > best) best = run; } else run = 0; }
  return { cur, best, total: Object.keys(log).filter(k => log[k]).length };
}
function habitPct(h, days) {
  const log = D.habitLog[h.id] || {}; let s = 0, n = 0, d = today();
  for (let i = 0; i < days && d >= h.start; i++) { if (sched(h, d)) { s++; if (log[d]) n++; } d = addDays(d, -1); }
  return s ? Math.round(n / s * 100) : 0;
}

/* ---------- stats ---------- */
function dayStats(d) {
  const ts = tasksOn(d), total = ts.length, done = ts.filter(t => t.isDone).length;
  const workload = ts.reduce((a, t) => a + Math.max(0, mins(t.end) - mins(t.start)), 0);
  const sch = D.rooms.filter(r => occurs(r, d)).reduce((a, r) => a + mins(r.end) - mins(r.start), 0);
  const focus = D.sessions.filter(s => s.date === d).reduce((a, s) => a + s.actualSec / 60, 0);
  const due = D.deadlines.filter(x => x.date === d && !x.done).length;
  const hs = habitsOn(d), hDone = hs.filter(h => (D.habitLog[h.id] || {})[d]).length;
  return { ts, total, done, pending: total - done, pct: total ? Math.round(done / total * 100) : 0, workload, sched: sch, focus, due, hTotal: hs.length, hDone };
}
function score(d) {
  const s = dayStats(d), p = [];
  if (s.total) p.push(s.done / s.total);
  if (s.hTotal) p.push(s.hDone / s.hTotal);
  if (s.sched) p.push(Math.min(1, s.focus / s.sched));
  if (!p.length && s.focus > 0) p.push(Math.min(1, s.focus / 60));
  return p.length ? Math.round(p.reduce((a, b) => a + b) / p.length * 100) : null;
}
function weekScores(d) {
  const s = addDays(d, -dow(d)), t = today();
  return [...Array(7)].map((_, i) => { const x = addDays(s, i); return { d: x, sc: x > t ? null : score(x) }; });
}
const maxStreak = () => Math.max(0, ...D.habits.filter(h => !h.paused).map(h => streak(h).cur));
const subjectsList = () => {
  const s = new Set((D.profile.subjects || '').split(',').map(x => x.trim()).filter(Boolean));
  D.exams.forEach(e => s.add(e.subject)); D.folders.forEach(f => s.add(f.name)); D.tasks.forEach(t => t.subject && s.add(t.subject));
  return [...s];
};

/* ---------- deadlines ---------- */
function cdParts(dl) {
  const ms = new Date(dl.date + 'T' + (dl.time || '23:59')).getTime() - Date.now(), a = Math.abs(ms);
  return { over: ms < 0, d: Math.floor(a / 864e5), h: Math.floor(a % 864e5 / 36e5), m: Math.floor(a % 36e5 / 6e4) };
}
const cdTxt = p => pad(p.d) + ':' + pad(p.h) + ':' + pad(p.m);

/* ---------- notifications (in-app + native) ---------- */
function addNotif(title, body, module, ref) {
  D.notifs.unshift({ id: uid(), title, body, at: Date.now(), read: false, module: module || '', ref: ref || '' });
  D.notifs = D.notifs.slice(0, 200); save();
  if (typeof R !== 'undefined' && R.auth == null && !R.stack.length && R.tab === 'home') render(true);
}
const unread = () => D ? D.notifs.filter(n => !n.read).length : 0;

function checkReminders() {
  if (!D) return;
  const now = new Date(), td = ymd(now), nm = now.getHours() * 60 + now.getMinutes(), P = D.prefs.notif;
  const fire = (key, f) => { if (D.fired[key]) return; D.fired[key] = 1; f(); };
  if (Object.keys(D.fired).length > 900) D.fired = {};
  if (P.tasks) tasksOn(td).forEach(t => {
    if (t.isDone || t.reminder === '' || t.reminder == null) return;
    const at = mins(t.start) - Number(t.reminder);
    if (nm >= at && nm < mins(t.end)) fire('t:' + t.id + td, () => addNotif('Upcoming: ' + t.title, fmtT(t.start) + ' - ' + fmtT(t.end), 'task', t.id + '|' + td));
  });
  if (P.deadlines) D.deadlines.forEach(x => {
    if (x.done) return; const c = cdParts(x);
    if (c.over) fire('d:' + x.id + ':over', () => addNotif('Deadline passed: ' + x.title, 'Due ' + fmtD(x.date) + ' ' + fmtT(x.time || '23:59'), 'deadline', x.id));
    else if (c.d === 0) fire('d:' + x.id + ':24', () => addNotif('Due within 24h: ' + x.title, 'Due ' + fmtD(x.date) + ' ' + fmtT(x.time || '23:59'), 'deadline', x.id));
  });
  if (P.focus) D.rooms.filter(r => occurs(r, td)).forEach(r => {
    if (nm >= mins(r.start) - 10 && nm < mins(r.end)) fire('r:' + r.id + td, () => addNotif('Focus room soon: ' + r.title, fmtT(r.start) + ' - ' + fmtT(r.end), 'room', r.id));
  });
  if (P.habits) habitsOn(td).forEach(h => {
    if (h.reminder && nm >= mins(h.reminder) && !(D.habitLog[h.id] || {})[td]) fire('h:' + h.id + td, () => addNotif('Habit reminder: ' + h.name, 'Not checked off yet today', 'habit', h.id));
  });
  if (P.exams) D.exams.forEach(e => {
    const diff = Math.round((pd(e.date) - pd(td)) / 864e5);
    if (diff === 1 || diff === 0) fire('e:' + e.id + td, () => addNotif((diff ? 'Exam tomorrow: ' : 'Exam today: ') + e.name, e.subject + (e.time ? ' at ' + fmtT(e.time) : ''), 'exam', e.id));
  });
}

let _ss = null;
function scheduleSoon() { clearTimeout(_ss); _ss = setTimeout(scheduleAll, 800); }
async function scheduleAll() {
  const LN = cap('LocalNotifications'); if (!LN || !D || !isNative()) return;
  try {
    const perm = await LN.checkPermissions(); if (perm.display !== 'granted') return;
    const pend = await LN.getPending();
    const old = pend.notifications.filter(n => n.id !== 777001);
    if (old.length) await LN.cancel({ notifications: old.map(n => ({ id: n.id })) });
    const list = [], now = Date.now(), P = D.prefs.notif, t0 = today();
    const add = (key, title, body, at) => { if (at > now + 5000 && list.length < 120) list.push({ id: h32(key), title, body, schedule: { at: new Date(at), allowWhileIdle: true }, smallIcon: 'ic_stat_icon_config_sample' }); };
    for (let i = 0; i < 14; i++) {
      const d = addDays(t0, i);
      if (P.tasks) tasksOn(d).forEach(t => {
        if (t.isDone || t.reminder === '' || t.reminder == null) return;
        add('t' + t.id + d, t.title, fmtT(t.start) + ' - ' + fmtT(t.end), new Date(d + 'T' + t.start).getTime() - Number(t.reminder) * 60000);
      });
      if (P.focus) D.rooms.filter(r => occurs(r, d)).forEach(r => add('r' + r.id + d, 'Focus room: ' + r.title, fmtT(r.start) + ' - ' + fmtT(r.end), new Date(d + 'T' + r.start).getTime() - 600000));
      if (P.habits) habitsOn(d).forEach(h => { if (h.reminder && !(D.habitLog[h.id] || {})[d]) add('h' + h.id + d, 'Habit: ' + h.name, 'Time to check it off', new Date(d + 'T' + h.reminder).getTime()); });
    }
    if (P.deadlines) D.deadlines.forEach(x => { if (!x.done) { const at = new Date(x.date + 'T' + (x.time || '23:59')).getTime(); add('dl' + x.id, 'Deadline in 1 hour', x.title, at - 3600000); add('dd' + x.id, 'Deadline in 1 day', x.title, at - 86400000); } });
    if (P.exams) D.exams.forEach(e => add('ex' + e.id, 'Exam tomorrow: ' + e.name, e.subject, new Date(addDays(e.date, -1) + 'T09:00').getTime()));
    if (list.length) await LN.schedule({ notifications: list });
  } catch (e) { /* notifications are best-effort */ }
}
