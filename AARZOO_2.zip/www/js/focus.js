'use strict';
/* ---------- range helpers ---------- */
function focusRange() {
  const t = today();
  if (R.focusRange === 'week') { const s = addDays(t, -dow(t)); return [s, addDays(s, 6)]; }
  if (R.focusRange === 'month') { const d = pd(t); return [ymd(new Date(d.getFullYear(), d.getMonth(), 1)), ymd(new Date(d.getFullYear(), d.getMonth() + 1, 0))]; }
  if (R.focusRange === 'custom' && validDate(R.fFrom) && validDate(R.fTo) && R.fFrom <= R.fTo) return [R.fFrom, R.fTo];
  return [t, t];
}
function eachDay(a, b) { const o = []; for (let d = a, i = 0; d <= b && i < 400; d = addDays(d, 1), i++) o.push(d); return o; }
const roomMins = r => mins(r.end) - mins(r.start);
const roomSessions = (r, d) => D.sessions.filter(s => s.roomId === r.id && s.date === d);
function roomState(r, d) {
  const done = roomSessions(r, d).filter(s => s.status === 'completed' || s.actualSec >= 60);
  if (done.length) return { k: 'done', sec: done.reduce((a, s) => a + s.actualSec, 0) };
  if (d < today() || (d === today() && new Date().getHours() * 60 + new Date().getMinutes() >= mins(r.end))) return { k: 'over' };
  return { k: 'open' };
}

/* ---------- Focus screen ---------- */
SCREENS.focus = () => {
  const [a, b] = focusRange(), days = eachDay(a, b);
  const actual = D.sessions.filter(s => s.date >= a && s.date <= b).reduce((x, s) => x + s.actualSec / 60, 0);
  const sch = days.reduce((x, d) => x + D.rooms.filter(r => occurs(r, d)).reduce((y, r) => y + roomMins(r), 0), 0);
  const pct = sch ? Math.min(100, Math.round(actual / sch * 100)) : 0;
  const items = []; days.forEach(d => D.rooms.filter(r => occurs(r, d)).forEach(r => items.push({ r, d })));
  items.sort((x, y) => (x.d + x.r.start).localeCompare(y.d + y.r.start));
  const ts = D.timerState;
  return `${hdr('Focus Stream', 'Scheduled deep work rooms', `<button class="ib big" data-a="go" data-to="push:tcustom">${ic('target')}</button><button class="ib big" data-a="frefresh">${ic('refresh')}</button>`)}
  <div class="row between"><h3>Overview</h3><label class="sel">${ic('cal', 16)}<select id="frange">${[['today', 'Today'], ['week', 'This Week'], ['month', 'This Month'], ['custom', 'Custom']].map(o => `<option value="${o[0]}" ${R.focusRange === o[0] ? 'selected' : ''}>${o[1]}</option>`).join('')}</select></label></div>
  ${R.focusRange === 'custom' ? `<div class="two" style="margin-top:12px"><input class="inp" type="date" id="ffrom" value="${R.fFrom}"><input class="inp" type="date" id="fto" value="${R.fTo}"></div>` : ''}
  <div class="card" style="margin-top:14px"><div class="row"><span class="ib" style="color:var(--gr)">${ic('pulse', 20)}</span><b style="font-size:18px">Focus Engine</b></div>
    <div class="fe"><div><b>${dur(actual)}</b><small>ACTUAL FOCUSED</small></div><div><b style="color:var(--tx)">${dur(sch)}</b><small>TOTAL SCHEDULED</small></div></div>
    <div class="bar"><i style="width:${pct}%"></i></div><small style="display:block;margin-top:8px">${sch ? pct + '% of scheduled focus time completed' : 'Schedule a room to set a focus target'}</small></div>
  ${ts ? `<button class="card full" style="width:100%;margin-top:14px;text-align:left;border-color:var(--acc)" data-a="go" data-to="push:timer"><div class="row between"><div><b>Session in progress</b><small style="display:block;margin-top:4px">${esc(ts.title || 'Focus session')} · ${ts.running ? 'running' : 'paused'}</small></div><span class="tag">OPEN</span></div></button>` : `<button class="btn pri full" style="margin-top:14px" data-a="quickfocus">${ic('play', 18)} Start a focus session</button>`}
  <div class="sec"><h3>Rooms You Host</h3><button class="btn sm" style="color:var(--acc);border-color:var(--acc)" data-a="addroom">${ic('plus', 16)} New Room</button></div>
  ${items.length ? items.map(({ r, d }) => roomCard(r, d)).join('') : empty('No rooms scheduled', 'Create a room to plan a deep-work block.', 'target')}
  <button class="fab" data-a="addroom">${ic('plus', 28)}</button>`;
};
function roomCard(r, d) {
  const st = roomState(r, d), many = R.focusRange !== 'today';
  return `<div class="room ${st.k === 'over' ? 'over' : ''}" style="--c:${r.color}" data-a="roomd" data-id="${r.id}" data-d="${d}"><div class="row between"><div class="row grow" style="min-width:0"><span class="ib" style="color:${r.color}">${ic('user', 18)}</span><h3 style="overflow-wrap:anywhere">${esc(r.title)}</h3></div><div class="row"><button class="ib sm" data-a="roomedit" data-id="${r.id}">${ic('edit', 15)}</button><button class="ib sm red" data-a="roomdel" data-id="${r.id}">${ic('trash', 15)}</button></div></div>
  <div class="row mut" style="margin:12px 0 0;font-size:15px">${ic('clock', 16)} <span>${many ? fmtD(d) + ' · ' : ''}${fmtT(r.start)} - ${fmtT(r.end)} (${roomMins(r)} mins)</span></div>
  ${st.k === 'over' ? `<div class="warn">${ic('alert', 15)} Time is over. Edit to reuse.</div>` : st.k === 'done' ? `<div class="okb">Completed · ${dur(st.sec / 60)} focused</div>` : `<div class="row" style="margin-top:12px"><span class="tag ye">${d === today() ? 'Today' : 'Upcoming'}</span>${r.subject ? `<span class="tag">${esc(r.subject)}</span>` : ''}${d === today() ? `<button class="btn pri sm" style="margin-left:auto" data-a="roomstart" data-id="${r.id}" data-d="${d}">${ic('play', 14)} Start</button>` : ''}</div>`}</div>`;
}
A.frefresh = () => { render(true); toast('Refreshed'); };
document.addEventListener('change', e => {
  if (e.target.id === 'frange') { R.focusRange = e.target.value; if (R.focusRange === 'custom' && !R.fFrom) { R.fFrom = addDays(today(), -6); R.fTo = today(); } render(true); }
  if (e.target.id === 'ffrom') { R.fFrom = e.target.value; render(true); }
  if (e.target.id === 'fto') { R.fTo = e.target.value; render(true); }
});
A.addroom = () => roomForm(null);
A.roomedit = el => roomForm(D.rooms.find(r => r.id === el.dataset.id));
A.roomdel = el => { const r = D.rooms.find(x => x.id === el.dataset.id); confirmBox('Delete room?', '"' + r.title + '" will be removed. Past focus sessions stay in your stats.', () => { D.rooms = D.rooms.filter(x => x.id !== r.id); save(); closeSheet(); render(true); toast('Room deleted'); scheduleSoon(); }); };
function roomForm(r) {
  const n = new Date(), s0 = hm(Math.min(1380, Math.ceil((n.getHours() * 60 + n.getMinutes() + 5) / 5) * 5));
  const e = r || { date: today(), start: s0, end: hm(Math.min(1439, mins(s0) + 30)), color: '#20D6A5', repeat: 'none', reminder: '10', repeatDays: [] };
  formSheet(r ? 'Edit focus room' : 'New focus room',
    F.t('Room title *', 'title', e.title, 'e.g. Assignment & project work') + F.a('Description', 'desc', e.desc) + F.d('Date', 'date', e.date) + `<div class="two">${F.tm('Start', 'start', e.start)}${F.tm('End', 'end', e.end)}</div>` + F.num('Duration (minutes)', 'dur', mins(e.end) - mins(e.start), '', 'min="5"') +
    F.t('Subject', 'subject', e.subject, '', 'list="subjl"') + `<datalist id="subjl">${subjectsList().map(s => `<option value="${esc(s)}">`).join('')}</datalist>` + F.col('color', e.color) +
    F.s('Reminder', 'reminder', [['', 'None'], ['5', '5 min before'], ['10', '10 min before'], ['30', '30 min before']], e.reminder == null ? '' : e.reminder) + F.s('Repeat', 'repeat', [['none', 'Does not repeat'], ['daily', 'Every day'], ['weekly', 'Every week'], ['custom', 'Custom days']], e.repeat) + F.days(e.repeatDays),
    v => {
      if (!v.title.trim()) return 'Room title is required.';
      if (!validDate(v.date)) return 'Pick a valid date.';
      if (!validTime(v.start)) return 'Pick a start time.';
      let end = v.end; if (!validTime(end)) { const dm = +v.dur; if (dm > 0 && mins(v.start) + dm < 1440) end = hm(mins(v.start) + dm); else return 'Pick an end time.'; }
      if (mins(end) <= mins(v.start)) return 'End time must be later than start time.';
      const rd = pickDays(v); if (v.repeat === 'custom' && !rd.length) return 'Select at least one repeat day.';
      const o = { title: v.title.trim(), desc: v.desc.trim(), date: v.date, start: v.start, end, subject: v.subject.trim(), color: v.color, reminder: v.reminder, repeat: v.repeat, repeatDays: rd };
      if (r) Object.assign(r, o); else D.rooms.push({ id: uid(), created: Date.now(), ...o });
      save(); closeSheet(); toast(r ? 'Room updated' : 'Room created'); render(true); scheduleSoon();
    }, { onDel: r ? () => A.roomdel({ dataset: { id: r.id } }) : null });
}
A.roomd = el => {
  const r = D.rooms.find(x => x.id === el.dataset.id), d = el.dataset.d, st = roomState(r, d), ss = roomSessions(r, d);
  infoSheet(r.title, `<div class="row" style="margin-bottom:8px"><span class="tag ${st.k === 'done' ? 'gr' : st.k === 'over' ? 'red' : 'ye'}">${st.k === 'done' ? 'COMPLETED' : st.k === 'over' ? 'TIME IS OVER' : 'SCHEDULED'}</span></div>` + kv('Date', fmtD(d, { weekday: 'long', month: 'long', day: 'numeric' })) + kv('Time', fmtT(r.start) + ' - ' + fmtT(r.end) + ' (' + roomMins(r) + ' mins)') + kv('Subject', esc(r.subject)) + kv('Description', esc(r.desc)) + kv('Repeat', r.repeat === 'none' ? '' : r.repeat) +
    (ss.length ? `<h3 style="margin:16px 0 4px;font-size:15px">Sessions</h3>${ss.map(s => `<div class="kv"><span>${new Date(s.startedAt).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}</span><b>${dur(s.actualSec / 60)} · ${s.status}</b></div>`).join('')}` : ''),
    `<button class="btn" data-a="roomedit" data-id="${r.id}">Edit</button>${d === today() ? `<button class="btn pri" data-a="roomstart" data-id="${r.id}" data-d="${d}">Start</button>` : ''}`);
};

/* ---------- timer engine (timestamp based, survives backgrounding) ---------- */
const T = {
  elapsed() { const s = D.timerState; return s ? s.acc + (s.running ? Date.now() - s.startedAt : 0) : 0; },
  start(o) {
    if (D.timerState) return false;
    D.timerState = { running: true, startedAt: Date.now(), acc: 0, planned: o.planned || 0, title: o.title || 'Focus session', subject: o.subject || '', roomId: o.roomId || '', began: Date.now(), date: today() };
    save(); T.notify(); return true;
  },
  pause() { const s = D.timerState; if (!s || !s.running) return; s.acc += Date.now() - s.startedAt; s.running = false; save(); T.cancel(); },
  resume() { const s = D.timerState; if (!s || s.running) return; s.startedAt = Date.now(); s.running = true; save(); T.notify(); },
  reset() { const s = D.timerState; if (!s) return; s.acc = 0; s.startedAt = Date.now(); save(); if (s.running) T.notify(); },
  finish(status) {
    const s = D.timerState; if (!s) return null;
    let ms = T.elapsed(); if (s.planned) ms = Math.min(ms, s.planned * 60000);
    const rec = { id: uid(), roomId: s.roomId, title: s.title, subject: s.subject, date: s.date, plannedMin: s.planned, actualSec: Math.round(ms / 1000), status: status, startedAt: s.began, endedAt: Date.now() };
    D.timerState = null; T.cancel();
    if (rec.actualSec >= 5) { D.sessions.push(rec); if (status === 'completed') addNotif('Focus session complete', rec.title + ' · ' + dur(rec.actualSec / 60), 'focus', rec.id); }
    save(); return rec.actualSec >= 5 ? rec : null;
  },
  async notify() {
    const LN = cap('LocalNotifications'), s = D.timerState; if (!LN || !isNative() || !s || !s.planned) return;
    try { await LN.cancel({ notifications: [{ id: 777001 }] }); const left = s.planned * 60000 - T.elapsed(); if (left > 2000 && D.prefs.notif.focus) await LN.schedule({ notifications: [{ id: 777001, title: 'Focus session complete', body: s.title, schedule: { at: new Date(Date.now() + left), allowWhileIdle: true } }] }); } catch (e) { }
  },
  async cancel() { const LN = cap('LocalNotifications'); if (LN && isNative()) { try { await LN.cancel({ notifications: [{ id: 777001 }] }); } catch (e) { } } }
};
const clock = sec => { sec = Math.max(0, Math.floor(sec)); return pad(Math.floor(sec / 3600)) + ':' + pad(Math.floor(sec % 3600 / 60)) + ':' + pad(sec % 60); };
function timerView() {
  const s = D.timerState, el = T.elapsed() / 1000;
  if (!s) return { txt: clock((R.tplan || 25) * 60), frac: 0 };
  if (s.planned) return { txt: clock(s.planned * 60 - el), frac: Math.min(1, el / (s.planned * 60)) };
  return { txt: clock(el), frac: (el % 3600) / 3600 };
}
A.quickfocus = () => { R.tplan = 25; push('timer'); };
A.roomstart = el => {
  const r = D.rooms.find(x => x.id === el.dataset.id); if (!r) return;
  if (D.timerState) { closeSheet(); return push('timer'); }
  T.start({ planned: roomMins(r), title: r.title, subject: r.subject, roomId: r.id }); closeSheet(); push('timer');
};

/* ---------- timer face (shared by timer screen and customization preview) ---------- */
const FONTS = { sans: 'Inter,Roboto,system-ui,sans-serif', mono: 'ui-monospace,"Roboto Mono",Menlo,monospace', serif: 'Georgia,"Times New Roman",serif', rounded: '"Varela Round",Nunito,system-ui,sans-serif' };
function tface(p, v) {
  const C = 2 * Math.PI * 88, glow = `filter:drop-shadow(0 0 ${p.glow / 6}px ${p.ring})`, tr = `transition:stroke-dashoffset ${(1.2 - p.anim / 100).toFixed(2)}s linear`;
  const off = C * (1 - v.frac);
  let svg = '';
  if (p.face === 'ring') svg = `<svg viewBox="0 0 200 200"><circle cx="100" cy="100" r="88" fill="none" stroke="${p.ring}" stroke-opacity=".15" stroke-width="${p.thick}"/><circle id="tfRing" cx="100" cy="100" r="88" fill="none" stroke="${p.ring}" stroke-width="${p.thick}" stroke-linecap="round" stroke-dasharray="${C}" stroke-dashoffset="${off}" transform="rotate(-90 100 100)" style="${glow};${tr}"/></svg>`;
  else if (p.face === 'segments') svg = `<svg viewBox="0 0 200 200"><defs><mask id="tfm"><circle id="tfRing" cx="100" cy="100" r="88" fill="none" stroke="#fff" stroke-width="${p.thick + 4}" stroke-dasharray="${C}" stroke-dashoffset="${off}" transform="rotate(-90 100 100)"/></mask></defs><circle cx="100" cy="100" r="88" fill="none" stroke="${p.ring}" stroke-opacity=".15" stroke-width="${p.thick}" stroke-dasharray="3 6.2"/><circle cx="100" cy="100" r="88" fill="none" stroke="${p.ring}" stroke-width="${p.thick}" stroke-dasharray="3 6.2" mask="url(#tfm)" style="${glow}"/></svg>`;
  else if (p.face === 'minimal') svg = `<svg viewBox="0 0 200 200"><circle cx="100" cy="100" r="88" fill="none" stroke="${p.ring}" stroke-opacity=".15" stroke-width="2"/><circle id="tfRing" cx="100" cy="100" r="88" fill="none" stroke="${p.ring}" stroke-width="2" stroke-linecap="round" stroke-dasharray="${C}" stroke-dashoffset="${off}" transform="rotate(-90 100 100)" style="${tr}"/></svg>`;
  const fam = FONTS[p.font] || FONTS.sans, w = p.face === 'digital' ? '100%' : p.size + '%';
  const text = `<div class="tf-t" id="tfText" style="font-family:${fam};font-size:${p.textSize}px;font-weight:${p.weight};color:${p.text};text-align:${p.align};text-shadow:0 0 ${p.glow / 5}px ${p.text}55">${v.txt}</div>`;
  const label = p.label ? `<div class="tf-l" style="color:${p.text}">${esc(p.label)}</div>` : '';
  const bar = p.face === 'digital' ? `<div class="bar" style="width:80%;background:${p.ring}22;margin-top:6px;height:${Math.max(4, p.thick)}px"><i id="tfBar" style="width:${v.frac * 100}%;background:${p.ring}"></i></div>` : '';
  return `<div class="tf-w" style="width:${w};${p.face === 'digital' ? '' : 'aspect-ratio:1'}">${svg}<div class="tf-c" style="${p.face === 'digital' ? 'position:static;' : ''}gap:${p.gap}px">${text}${label}${bar}</div></div>`;
}
const VPOS = { top: 'flex-start', center: 'center', bottom: 'flex-end' };

/* ---------- timer screen ---------- */
SCREENS.timer = () => {
  const p = D.prefs.timer, s = D.timerState, v = timerView();
  const ctl = s ? `${s.running ? `<button class="btn pri" data-a="tpause">${ic('pause', 18)} Pause</button>` : `<button class="btn pri" data-a="tresume">${ic('play', 18)} Resume</button>`}<button class="btn danger" data-a="tstop">${ic('stop', 18)} Stop</button><button class="btn" data-a="treset">${ic('refresh', 18)} Reset</button>`
    : `<div class="card" style="width:100%"><label class="fl"><span>Session length</span><select class="inp" id="tplan">${[[0, 'Stopwatch (no limit)'], [15, '15 minutes'], [25, '25 minutes'], [30, '30 minutes'], [45, '45 minutes'], [60, '60 minutes'], [90, '90 minutes']].map(o => `<option value="${o[0]}" ${(R.tplan == null ? 25 : R.tplan) == o[0] ? 'selected' : ''}>${o[1]}</option>`).join('')}</select></label><label class="fl"><span>Subject (optional)</span><input class="inp" id="tsub" list="subjl" placeholder="e.g. Data Structures" value="${esc(R.tsub || '')}"></label><datalist id="subjl">${subjectsList().map(x => `<option value="${esc(x)}">`).join('')}</datalist><button class="btn pri full" data-a="tstart">${ic('play', 18)} Start</button></div>`;
  return `<div class="tscreen" style="background:${p.bg};color:${p.text}"><div class="row between"><button class="ib" data-a="back" style="background:#ffffff10;border-color:#ffffff22">${ic('back')}</button><div class="mut" style="font-size:14px">${s ? esc(s.title) : 'Focus timer'}</div><button class="ib" data-a="go" data-to="push:tcustom" style="background:#ffffff10;border-color:#ffffff22">${ic('sliders')}</button></div>
  <div class="tface" style="justify-content:${VPOS[p.vpos] || 'center'}">${tface(p, v)}</div><div class="tctl">${ctl}</div></div>`;
};
document.addEventListener('change', e => { if (e.target.id === 'tplan') R.tplan = +e.target.value; });
document.addEventListener('input', e => { if (e.target.id === 'tsub') R.tsub = e.target.value; });
A.tstart = () => { const m = R.tplan == null ? 25 : R.tplan; T.start({ planned: m, title: R.tsub ? R.tsub : 'Focus session', subject: R.tsub || '' }); render(); };
A.tpause = () => { T.pause(); render(); };
A.tresume = () => { T.resume(); render(); };
A.treset = () => confirmBox('Reset timer?', 'Elapsed time goes back to zero and is not recorded.', () => { T.reset(); render(); }, 'Reset');
A.tstop = () => confirmBox('Stop session?', 'The time you focused so far will be saved.', () => { const r = T.finish('stopped'); R.stack.pop(); render(); if (r) summary(r); else toast('Session too short to record'); }, 'Stop');
function summary(r) {
  infoSheet('Session summary', `<div style="text-align:center;margin:6px 0 14px"><div style="font-size:40px;font-weight:800;color:var(--gr)">${r.actualSec < 60 ? r.actualSec + 's' : dur(r.actualSec / 60)}</div><small>focused</small></div>` + kv('Status', r.status === 'completed' ? 'Completed' : 'Stopped early') + kv('Planned', r.plannedMin ? r.plannedMin + ' min' : 'Open-ended') + kv('Actual', clock(r.actualSec)) + kv('Date', fmtD(r.date, { weekday: 'short', month: 'short', day: 'numeric' })) + kv('Subject', esc(r.subject || r.title)));
}
/* global tick: updates live elements without re-rendering */
function timerTick() {
  if (!D) return;
  if (D.timerState && D.timerState.running && D.timerState.planned && T.elapsed() >= D.timerState.planned * 60000) {
    const r = T.finish('completed'); if (curScreen().name === 'timer') { R.stack.pop(); }
    render(true); if (r) { summary(r); toast('Focus session complete'); } return;
  }
  const tf = $('#tfText'); if (tf) {
    const v = timerView(); tf.textContent = v.txt;
    const rg = $('#tfRing'); if (rg) rg.style.strokeDashoffset = 2 * Math.PI * 88 * (1 - v.frac);
    const b = $('#tfBar'); if (b) b.style.width = v.frac * 100 + '%';
  }
}

/* ---------- timer customization ---------- */
const TTABS = [['layout', 'Layout'], ['text', 'Text'], ['color', 'Color'], ['face', 'Face'], ['tweak', 'Tweak']];
const PRESETS = { classic: { size: 72, textSize: 44, vpos: 'center' }, compact: { size: 55, textSize: 34, vpos: 'top' }, big: { size: 92, textSize: 54, vpos: 'center' } };
SCREENS.tcustom = () => {
  const p = D.prefs.timer; R.ttab = R.ttab || 'layout';
  return `${hdr('Customize timer', 'Changes save automatically')}
  <div class="tprev" id="tprev" style="background:${p.bg}">${tface(p, { txt: '00:27:34', frac: .62 })}</div>
  <div class="seg">${TTABS.map(t => `<button class="${R.ttab === t[0] ? 'on' : ''}" data-a="ttab" data-t="${t[0]}">${t[1]}</button>`).join('')}</div>
  <div id="tpanel">${tpanel(p)}</div>
  <div class="two" style="margin-top:16px"><button class="btn" data-a="treset2">Reset</button><button class="btn pri" data-a="tapply">Apply</button></div><button class="btn full" style="margin-top:10px" data-a="back">Close</button>`;
};
const opts = (k, list) => `<div class="seg" style="flex-wrap:wrap">${list.map(o => `<button class="${D.prefs.timer[k] === o[0] ? 'on' : ''}" data-a="tset" data-k="${k}" data-v="${o[0]}">${o[1]}</button>`).join('')}</div>`;
const rng = (l, k, min, max) => `<label class="fl"><span>${l}: <b id="rv_${k}">${D.prefs.timer[k]}</b></span><input type="range" min="${min}" max="${max}" value="${D.prefs.timer[k]}" data-tk="${k}"></label>`;
function tpanel(p) {
  const t = R.ttab;
  if (t === 'layout') return `<div class="fl"><span>Layout preset</span>${opts('preset', [['classic', 'Classic'], ['compact', 'Compact'], ['big', 'Big']])}</div><div class="fl"><span>Vertical position</span>${opts('vpos', [['top', 'Top'], ['center', 'Center'], ['bottom', 'Bottom']])}</div>${rng('Timer size (%)', 'size', 40, 100)}`;
  if (t === 'text') return `<div class="fl"><span>Font</span>${opts('font', [['sans', 'Sans'], ['mono', 'Mono'], ['serif', 'Serif'], ['rounded', 'Rounded']])}</div>${rng('Text size', 'textSize', 22, 80)}<div class="fl"><span>Weight</span>${opts('weight', [[400, 'Regular'], [600, 'Semi'], [700, 'Bold'], [900, 'Black']])}</div><label class="fl"><span>Timer label</span><input class="inp" data-tk="label" value="${esc(p.label)}" maxlength="24"></label><div class="fl"><span>Text alignment</span>${opts('align', [['left', 'Left'], ['center', 'Center'], ['right', 'Right']])}</div>`;
  if (t === 'color') { R.ctarget = R.ctarget || 'ring'; const cur = p[R.ctarget]; return `<div class="seg">${[['ring', 'Ring'], ['text', 'Text'], ['bg', 'Background']].map(o => `<button class="${R.ctarget === o[0] ? 'on' : ''}" data-a="ctarget" data-t="${o[0]}">${o[1]}</button>`).join('')}</div><div class="swatches">${PAL2.map(c => `<i class="sw ${c.toLowerCase() === String(cur).toLowerCase() ? 'on' : ''}" style="background:${c};border-color:${c.toLowerCase() === String(cur).toLowerCase() ? 'var(--tx)' : 'transparent'}" data-a="tcolor" data-c="${c}"></i>`).join('')}</div><label class="row" style="margin-top:14px"><span class="mut">Custom color</span><input type="color" value="${/^#[0-9a-f]{6}$/i.test(cur) ? cur : '#08D9F2'}" data-tk="${R.ctarget}"></label>`; }
  if (t === 'face') return `<div class="fl"><span>Timer style</span>${opts('face', [['ring', 'Ring'], ['segments', 'Segments'], ['digital', 'Digital'], ['minimal', 'Minimal']])}</div>`;
  return `${rng('Ring thickness', 'thick', 2, 16)}${rng('Glow intensity', 'glow', 0, 100)}${rng('Animation speed', 'anim', 0, 100)}${rng('Spacing', 'gap', 0, 30)}`;
}
function tprev() { const p = D.prefs.timer; $('#tprev').style.background = p.bg; $('#tprev').innerHTML = tface(p, { txt: '00:27:34', frac: .62 }); }
A.ttab = el => { R.ttab = el.dataset.t; render(true); };
A.ctarget = el => { R.ctarget = el.dataset.t; render(true); };
A.tset = el => {
  const k = el.dataset.k, v = el.dataset.v, p = D.prefs.timer;
  p[k] = ['weight'].includes(k) ? +v : v;
  if (k === 'preset') Object.assign(p, PRESETS[v]);
  save(); render(true);
};
A.tcolor = el => { D.prefs.timer[R.ctarget || 'ring'] = el.dataset.c; save(); render(true); };
document.addEventListener('input', e => {
  const k = e.target.dataset && e.target.dataset.tk; if (!k || !D) return;
  const p = D.prefs.timer; p[k] = e.target.type === 'range' ? +e.target.value : e.target.value;
  const rv = $('#rv_' + k); if (rv) rv.textContent = p[k];
  save(); tprev();
});
A.treset2 = () => { D.prefs.timer = { ...TPREF }; save(); render(true); toast('Timer settings reset'); };
A.tapply = () => { save(); toast('Timer settings applied'); pop(); };
