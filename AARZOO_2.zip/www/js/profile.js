'use strict';
/* ---------- Control Center ---------- */
SCREENS.profile = () => {
  const p = D.profile, tile = (to, icon, col, t, s2, extra) => `<button class="card gtile" style="--c:${col}" data-a="go" data-to="${to}" ${extra || ''}><i>${ic(icon, 22)}</i><span><b>${t}</b><small>${s2}</small></span></button>`;
  const row = (a, icon, t, red) => `<button class="set ${red ? 'red' : ''}" data-a="${a}"><i>${ic(icon, 20)}</i><b class="grow">${t}</b>${ic('chev', 18)}</button>`;
  return `${hdr('Control Center', 'Your master hub for everything AARZOO.')}
  <div class="card pc"><div class="pav">${avatar(p)}<button data-a="pickphoto" aria-label="Change photo">${ic('camera', 16)}</button></div><div class="grow"><h3 style="overflow-wrap:anywhere">${esc(p.name || 'Student')}</h3><small style="display:block;margin-top:4px;overflow-wrap:anywhere">${esc(USER.email)}</small><button class="pid" data-a="copyid"># ${USER.pubId}</button></div></div>
  <div class="two" style="margin-top:14px"><button class="card gtile" style="--c:#20D6A5" data-a="go" data-to="push:friends"><i>${ic('users', 22)}</i><span><b style="font-size:26px">0</b><small>Total Friends</small></span></button><button class="card gtile" style="--c:#08D9F2" data-a="go" data-to="push:friends"><i>${ic('userplus', 22)}</i><span><b style="font-size:22px">Add</b><small>New Friend</small></span></button></div>
  <div class="cap">APP ECOSYSTEM</div>
  <div class="two">${tile('tab:day', 'cal', '#8B7BFF', 'Planner', 'Daily Tasks')}${tile('push:exams', 'cpu', '#F52C79', 'Exam AI', 'Smart Planner')}${tile('tab:vault', 'folder', '#08D9F2', 'Vault', 'Your Notes')}${tile('tab:focus', 'target', '#FFD166', 'Focus Stream', 'Deep Work')}</div>
  <div class="cap">INSIGHTS</div>
  ${row('go_analytics', 'bars', 'Productivity analytics')}${row('go_search', 'search', 'Search everything')}${row('go_notifs', 'chat', 'Notifications & messages')}
  <div class="cap">SETTINGS</div>
  ${row('editprofile', 'user', 'Edit profile')}${row('go_account', 'lock', 'Account settings')}${row('go_notifset', 'bell', 'Notification settings')}${row('go_appearance', 'palette', 'Appearance')}${row('go_tcustom', 'sliders', 'Focus customization')}${row('go_privacy', 'lock', 'Privacy')}${row('exportdata', 'download', 'Export my data')}${row('go_help', 'help', 'Help & support')}${row('go_about', 'help', 'About AARZOO')}${row('logout', 'logout', 'Log out', true)}`;
};
const GO = { go_analytics: 'analytics', go_search: 'search', go_notifs: 'notifs', go_account: 'account', go_notifset: 'notifset', go_appearance: 'appearance', go_tcustom: 'tcustom', go_privacy: 'privacy', go_help: 'help', go_about: 'about' };
Object.keys(GO).forEach(k => A[k] = () => push(GO[k]));
A.copyid = async () => { try { await navigator.clipboard.writeText(USER.pubId); toast('Friend ID copied'); } catch (e) { shareText('My AARZOO ID', USER.pubId); } };

/* ---------- edit profile + photo ---------- */
A.editprofile = () => {
  const p = D.profile;
  formSheet('Edit profile', F.t('Full name *', 'name', p.name) + `<div class="fl"><span>Email</span><div class="inp" style="color:var(--mut)">${esc(USER.email)}</div></div>` + F.t('College / university', 'college', p.college) + F.t('Course', 'course', p.course) + F.t('Semester / year', 'semester', p.semester) + F.t('Subjects (comma separated)', 'subjects', p.subjects) + F.a('Bio', 'bio', p.bio),
    v => { if (!v.name.trim()) return 'Name is required.'; Object.assign(D.profile, { name: v.name.trim(), college: v.college.trim(), course: v.course.trim(), semester: v.semester.trim(), subjects: v.subjects.trim(), bio: v.bio.trim() }); USER.name = D.profile.name; Acc.users().then(us => { const u = us.find(x => x.id === USER.id); if (u) { u.name = USER.name; Acc.saveUsers(us); } }); save(); closeSheet(); render(true); toast('Profile updated'); });
};
A.pickphoto = () => $('#photoIn').click();
let _pend = null;
function squareImg(file, size) {
  return new Promise((ok, no) => {
    const url = URL.createObjectURL(file), im = new Image();
    im.onload = () => { const s = Math.min(im.width, im.height), c = document.createElement('canvas'); c.width = c.height = size; c.getContext('2d').drawImage(im, (im.width - s) / 2, (im.height - s) / 2, s, s, 0, 0, size, size); URL.revokeObjectURL(url); ok(c.toDataURL('image/jpeg', .86)); };
    im.onerror = () => { URL.revokeObjectURL(url); no(new Error('bad image')); }; im.src = url;
  });
}
$('#photoIn').addEventListener('change', async e => {
  const f = e.target.files[0]; e.target.value = ''; if (!f || !D) return;
  if (!f.type.startsWith('image/')) return toast('Please choose an image file', true);
  try { _pend = await squareImg(f, 360); infoSheet('Profile photo', `<img class="pv" src="${_pend}" alt="Preview"><p class="mut" style="text-align:center;font-size:13px">Cropped to a centered square.</p>`, `<button class="btn" data-a="sheetclose">Cancel</button><button class="btn pri" data-a="savephoto">Use this photo</button>`); }
  catch (err) { toast('Could not read that image. Try another one.', true); }
});
A.savephoto = () => { if (!_pend) return; D.profile.photo = _pend; _pend = null; save(); closeSheet(); render(true); toast('Profile photo updated'); };

/* ---------- friends (needs an online backend) ---------- */
SCREENS.friends = () => `${hdr('Friends', 'Study together')}
<div class="card pc"><div class="grow"><small>Your friend ID</small><div class="pid" style="font-size:22px"># ${USER.pubId}</div></div><button class="btn sm" data-a="shareid">${ic('share', 16)} Share</button></div>
<div class="empty-note" style="margin-top:14px">Friend requests, friend search, messaging and live sharing need an online backend, and this build stores everything on your phone. Nothing here is faked: it will switch on once a backend (for example Firebase) is connected. Until then, share notes and folders using the Share buttons in the Vault.</div>
<button class="set" data-a="shareid"><i>${ic('userplus', 20)}</i><b class="grow">Invite a friend with my ID</b>${ic('chev', 18)}</button>
<button class="set" data-a="go" data-to="tab:vault"><i>${ic('folder', 20)}</i><b class="grow">Share notes from the Vault</b>${ic('chev', 18)}</button>
${empty('No friends yet', 'Friend requests will appear here once a backend is connected.', 'users')}`;
A.shareid = () => shareText('Add me on AARZOO', 'Add me on AARZOO! My friend ID is #' + USER.pubId);

/* ---------- notifications & messages ---------- */
SCREENS.notifs = () => {
  const l = D.notifs;
  return `${hdr('Notifications', '', l.length ? `<button class="btn sm" data-a="readall">Mark all read</button>` : '')}
  <div class="seg"><button class="${R.ntab === 'n' ? 'on' : ''}" data-a="ntabs" data-t="n">Notifications${unread() ? ' (' + unread() + ')' : ''}</button><button class="${R.ntab === 'm' ? 'on' : ''}" data-a="ntabs" data-t="m">Messages</button></div>
  ${R.ntab === 'm' ? empty('Messaging is not connected', 'Friend messaging needs an online backend. Your conversations will appear here once one is connected.', 'chat') :
      l.length ? l.map(n => `<div class="nrow ${n.read ? 'rd' : 'un'}"><i class="nd"></i><div class="grow" data-a="nopen" data-id="${n.id}"><b>${esc(n.title)}</b><small style="display:block;margin-top:2px">${esc(n.body)}</small><small style="display:block;margin-top:6px;font-size:12px">${new Date(n.at).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}${n.module ? ' · ' + n.module : ''}</small></div><button class="ib sm" data-a="ndel" data-id="${n.id}">${ic('x', 14)}</button></div>`).join('') : empty('You are all caught up', 'Reminders for tasks, deadlines, habits, focus rooms and exams show up here.', 'bell')}`;
};
A.ntabs = el => { R.ntab = el.dataset.t; render(true); };
A.readall = () => { D.notifs.forEach(n => n.read = true); save(); render(true); };
A.ndel = el => { D.notifs = D.notifs.filter(n => n.id !== el.dataset.id); save(); render(true); };
A.nopen = el => {
  const n = D.notifs.find(x => x.id === el.dataset.id); if (!n) return; n.read = true; save();
  if (n.module === 'task') { const [id, d] = n.ref.split('|'); const t = findOcc(id, d); if (t) { render(true); return taskDetail(t); } }
  else if (n.module === 'deadline') { const x = D.deadlines.find(d => d.id === n.ref); if (x) { render(true); return dlDetail(x); } }
  else if (n.module === 'habit') { R.dayMode = 'habits'; return nav('day'); }
  else if (n.module === 'room' || n.module === 'focus') return nav('focus');
  else if (n.module === 'exam') { return push('exam', { id: n.ref }); }
  render(true);
};

/* ---------- global search ---------- */
SCREENS.search = () => `${hdr('Search', 'Tasks, notes, habits and more')}<div class="search">${ic('search')}<input id="gq" placeholder="Search everything" value="${esc(R.gq || '')}" autofocus></div><div id="gres">${gres(R.gq || '')}</div>`;
function gres(q) {
  q = q.trim().toLowerCase(); if (!q) return empty('Search AARZOO', 'Find tasks, deadlines, habits, notes, folders, focus rooms, exams and topics.', 'search');
  const m = s => (s || '').toLowerCase().includes(q), g = [];
  const sec = (t, items) => { if (items.length) g.push(`<div class="cap">${t}</div>${items.join('')}`); };
  const item = (a, title, sub, p) => `<button class="li" data-a="${a}" ${p || ''}><div class="grow"><b>${esc(title)}</b><small>${esc(sub || '')}</small></div>${ic('chev', 16)}</button>`;
  sec('TASKS', D.tasks.filter(t => m(t.title) || m(t.desc) || m(t.subject) || m(t.notes)).slice(0, 8).map(t => item('sr_task', t.title, fmtD(t.date) + ' · ' + fmtT(t.start), `data-id="${t.id}"`)));
  sec('DEADLINES', D.deadlines.filter(x => m(x.title) || m(x.desc)).slice(0, 8).map(x => item('dld', x.title, 'Due ' + fmtD(x.date), `data-id="${x.id}"`)));
  sec('HABITS', D.habits.filter(h => m(h.name) || m(h.desc)).map(h => item('hd', h.name, 'Streak ' + streak(h).cur, `data-id="${h.id}"`)));
  sec('NOTES', D.notes.filter(n => m(n.title) || m(txt(n.html))).slice(0, 8).map(n => item('go', n.title, nPreview(n), `data-to="push:note" data-p="${gop({ id: n.id })}"`)));
  sec('FOLDERS', D.folders.filter(f => m(f.name) || m(f.subject) || m(f.desc)).map(f => item('go', f.name, fCount(f) + ' items', `data-to="push:folder" data-p="${gop({ id: f.id })}"`)));
  sec('FOCUS ROOMS', D.rooms.filter(r => m(r.title) || m(r.subject) || m(r.desc)).map(r => item('go', r.title, fmtD(r.date) + ' · ' + fmtT(r.start), 'data-to="tab:focus"')));
  sec('EXAMS', D.exams.filter(e => m(e.name) || m(e.subject)).map(e => item('go', e.name, e.subject + ' · ' + fmtD(e.date), `data-to="push:exam" data-p="${gop({ id: e.id })}"`)));
  sec('SYLLABUS TOPICS', D.exams.flatMap(e => e.topics.filter(t => m(t.name) || m(t.chapter) || m(t.notes)).map(t => item('go', t.name, e.subject + (t.chapter ? ' · ' + t.chapter : ''), `data-to="push:exam" data-p="${gop({ id: e.id })}"`))).slice(0, 8));
  sec('STICKY NOTES', D.stickies.filter(s => m(s.text)).map(s => item('edst', s.text.slice(0, 60), '', `data-id="${s.id}"`)));
  return g.length ? g.join('') : empty('No results', 'Nothing matches "' + q + '".', 'search');
}
A.sr_task = el => { const t = D.tasks.find(x => x.id === el.dataset.id); if (t) taskDetail({ ...t, occ: t.date, isDone: !!(t.doneDates || {})[t.date] }); };

/* ---------- analytics ---------- */
SCREENS.analytics = () => {
  const hasData = D.tasks.length || D.habits.length || D.sessions.length || D.deadlines.length;
  const tabs = [['day', 'Daily'], ['week', 'Weekly'], ['month', 'Monthly']];
  return `${hdr('Analytics', 'Based on what you actually did')}<div class="seg">${tabs.map(t => `<button class="${R.anTab === t[0] ? 'on' : ''}" data-a="antab" data-t="${t[0]}">${t[1]}</button>`).join('')}</div>
  ${hasData ? (R.anTab === 'day' ? anDay() : R.anTab === 'week' ? anWeek() : anMonth()) : empty('No activity yet', 'Plan a task, tick a habit or finish a focus session and your charts appear here.', 'bars')}`;
};
A.antab = el => { R.anTab = el.dataset.t; render(true); };
const bars = (vals, labels, col, fmt) => { const mx = Math.max(1, ...vals); return `<div class="abars">${vals.map((v, i) => `<div><span>${fmt ? fmt(v) : v}</span><i style="height:${Math.max(3, v / mx * 90)}%;--c:${col}"></i><span>${labels[i]}</span></div>`).join('')}</div>`; };
function anDay() {
  const s = dayStats(R.sel), sc = score(R.sel);
  return `<div class="card row" style="gap:16px">${ring(s.pct, 100, `<span>${s.pct}%</span>`)}<div class="grow">${kv('Tasks completed', s.done + ' / ' + s.total)}${kv('Pending', s.pending)}${kv('Workload', dur(s.workload))}${kv('Focus', dur(s.focus))}${kv('Habits', s.hTotal ? s.hDone + ' / ' + s.hTotal : '-')}${kv('Productivity', sc == null ? '-' : sc + '%')}</div></div><p class="mut" style="font-size:13px;margin-top:10px">Showing ${fmtD(R.sel, { weekday: 'long', month: 'long', day: 'numeric' })}. Change the day from Home or My Day.</p>`;
}
function anWeek() {
  const w = weekScores(R.sel), ds = w.map(x => dayStats(x.d)), lab = w.map(x => pd(x.d).toLocaleDateString([], { weekday: 'narrow' }));
  const sc = w.filter(x => x.sc != null), best = sc.length ? sc.reduce((a, b) => b.sc > a.sc ? b : a) : null;
  const hr = ds.reduce((a, s) => a + s.hTotal, 0) ? Math.round(ds.reduce((a, s) => a + s.hDone, 0) / ds.reduce((a, s) => a + s.hTotal, 0) * 100) : null;
  return `<div class="card"><b>Productivity score</b>${bars(w.map(x => x.sc || 0), lab, 'var(--acc)', v => v || '')}<small style="display:block;margin-top:8px">${best ? 'Most productive: ' + pd(best.d).toLocaleDateString([], { weekday: 'long' }) + ' (' + best.sc + '%)' : 'No scored days yet'}</small></div>
  <div class="card" style="margin-top:12px"><b>Tasks completed</b>${bars(ds.map(s => s.done), lab, '#20D6A5')}</div>
  <div class="card" style="margin-top:12px"><b>Focus minutes</b>${bars(ds.map(s => Math.round(s.focus)), lab, '#8B36F5')}</div>
  <div class="card" style="margin-top:12px">${kv('Habit completion rate', hr == null ? '-' : hr + '%')}${kv('Total focus', dur(ds.reduce((a, s) => a + s.focus, 0)))}${kv('Tasks completed', ds.reduce((a, s) => a + s.done, 0))}</div>`;
}
function anMonth() {
  const d0 = pd(R.sel), y = d0.getFullYear(), m = d0.getMonth(), n = new Date(y, m + 1, 0).getDate(), first = new Date(y, m, 1).getDay(), t = today();
  let cells = '', act = 0, elapsed = 0, tasks = 0, focus = 0, dlDone = D.deadlines.filter(x => x.done && x.date.startsWith(ymd(d0).slice(0, 7))).length;
  for (let i = 0; i < first; i++) cells += '<div style="background:none"></div>';
  for (let i = 1; i <= n; i++) {
    const d = y + '-' + pad(m + 1) + '-' + pad(i), s = d <= t ? score(d) : null, st = dayStats(d);
    if (d <= t) { elapsed++; if (s != null && s > 0) act++; tasks += st.done; focus += st.focus; }
    cells += `<div style="${s != null ? `background:color-mix(in srgb,var(--acc) ${Math.max(12, s)}%,var(--card2));color:#001018;font-weight:700` : ''}">${i}</div>`;
  }
  const bestStreak = Math.max(0, ...D.habits.map(h => streak(h).best));
  return `<div class="card"><b>${d0.toLocaleDateString([], { month: 'long', year: 'numeric' })}</b><div class="heat">${cells}</div><small style="display:block;margin-top:8px">Darker cells mean a more productive day.</small></div>
  <div class="card" style="margin-top:12px">${kv('Total focus hours', (focus / 60).toFixed(1) + ' h')}${kv('Tasks completed', tasks)}${kv('Deadlines achieved', dlDone)}${kv('Longest habit streak', bestStreak + ' days')}${kv('Study consistency', elapsed ? Math.round(act / elapsed * 100) + '% of days active' : '-')}</div>`;
}

/* ---------- settings screens ---------- */
const toggle = (a, on, t, s) => `<div class="set"><div class="grow"><b>${t}</b>${s ? `<small style="display:block;margin-top:2px">${s}</small>` : ''}</div><button class="sw2 ${on ? 'on' : ''}" data-a="${a}"></button></div>`;
SCREENS.account = () => `${hdr('Account', 'Sign-in and security')}<div class="card">${kv('Name', esc(D.profile.name))}${kv('Email', esc(USER.email))}${kv('Friend ID', '#' + USER.pubId)}${kv('Member since', new Date(USER.created).toLocaleDateString([], { dateStyle: 'medium' }))}</div>
<button class="set" style="margin-top:14px" data-a="editprofile"><i>${ic('user', 20)}</i><b class="grow">Edit profile</b>${ic('chev', 18)}</button><button class="set" data-a="chgpw"><i>${ic('lock', 20)}</i><b class="grow">Change password</b>${ic('chev', 18)}</button><button class="set red" data-a="delacct"><i>${ic('trash', 20)}</i><b class="grow">Delete account and data</b></button>`;
A.chgpw = () => formSheet('Change password', F.t('Current password', 'old', '', '', 'type="password"') + F.t('New password (min 6)', 'nw', '', '', 'type="password"'), v => {
  if (v.nw.length < 6) return 'New password must be at least 6 characters.';
  const b = $('#fsave'); b.dataset.busy = 1;
  Acc.users().then(async us => { const u = us.find(x => x.id === USER.id); if (u.hash !== await Acc.hash(v.old)) { b.dataset.busy = ''; return $('#ferr').textContent = 'Current password is incorrect.'; } u.hash = await Acc.hash(v.nw); await Acc.saveUsers(us); closeSheet(); toast('Password changed'); });
});
A.delacct = () => confirmBox('Delete your account?', 'Everything stored for this account on this device is erased permanently.', async () => {
  for (const f of D.files) { try { await DBW.del('files', f.id); } catch (e) { } }
  const us = (await Acc.users()).filter(u => u.id !== USER.id); await Acc.saveUsers(us); await DBW.del('kv', 'data:' + USER.id);
  localStorage.removeItem('aarzoo_uid'); D = null; USER = null; R.stack = []; R.auth = 'signup'; renderAuth(); toast('Account deleted');
}, 'Delete everything');

SCREENS.notifset = () => { const P = D.prefs.notif; return `${hdr('Notifications', 'Choose what reminds you')}${[['tasks', 'Tasks'], ['deadlines', 'Deadlines'], ['habits', 'Habits'], ['focus', 'Focus rooms'], ['exams', 'Exams']].map(k => toggle('npref', P[k[0]], k[1], '').replace('data-a="npref"', `data-a="npref" data-k="${k[0]}"`)).join('')}
<button class="btn pri full" style="margin-top:8px" data-a="askperm">Allow notifications on this phone</button><p class="mut" style="font-size:13px;margin-top:10px;line-height:1.5">Reminders are scheduled on your phone for the next 14 days and refresh whenever you open the app. Set a reminder time on each task, habit or room to get one.</p>`; };
A.npref = el => { const k = el.dataset.k; D.prefs.notif[k] = !D.prefs.notif[k]; save(); render(true); scheduleSoon(); };
A.askperm = async () => { const LN = cap('LocalNotifications'); if (!LN || !isNative()) return toast('Notifications work in the installed Android app', true); try { const r = await LN.requestPermissions(); toast(r.display === 'granted' ? 'Notifications allowed' : 'Permission denied. Enable it in Android settings.', r.display !== 'granted'); scheduleAll(); } catch (e) { toast('Could not request permission', true); } };

SCREENS.appearance = () => `${hdr('Appearance', 'Theme and accent color')}<div class="seg"><button class="${D.prefs.theme === 'dark' ? 'on' : ''}" data-a="theme" data-t="dark">Dark</button><button class="${D.prefs.theme === 'light' ? 'on' : ''}" data-a="theme" data-t="light">Light</button></div><div class="card"><div class="fl"><span>Accent color</span><div class="swatches">${PAL.map(c => `<i class="sw ${c.toLowerCase() === D.prefs.accent.toLowerCase() ? 'on' : ''}" style="background:${c}" data-a="accent" data-c="${c}"></i>`).join('')}</div></div></div>`;
A.theme = el => { D.prefs.theme = el.dataset.t; save(); applyTheme(); render(true); };
A.accent = el => { D.prefs.accent = el.dataset.c; save(); applyTheme(); render(true); };

SCREENS.privacy = () => `${hdr('Privacy', 'Where your data lives')}<div class="card" style="line-height:1.55"><p>Your tasks, notes, files, habits and focus history are stored only on this phone, inside this app, under your account. Nothing is uploaded and no analytics are collected.</p><p style="margin-top:10px">Uninstalling the app or clearing its storage erases the data. Use <b>Export my data</b> to keep a backup.</p></div><button class="set" style="margin-top:14px" data-a="exportdata"><i>${ic('download', 20)}</i><b class="grow">Export my data</b>${ic('chev', 18)}</button>`;
A.exportdata = () => {
  const o = JSON.parse(JSON.stringify(D)); o.profile.photo = o.profile.photo ? '[photo omitted]' : ''; o.exportedAt = new Date().toISOString();
  shareBlob(new Blob([JSON.stringify(o, null, 2)], { type: 'application/json' }), 'aarzoo-data-' + today() + '.json');
};
SCREENS.help = () => `${hdr('Help & support', 'Quick answers')}${[['How do I add a task?', 'Open My Day and tap the + button, or tap + next to Today\'s Planner on Home.'], ['How do habits work?', 'Open My Day, switch to Habit Matrix and tap a box to tick a day. Tap a habit name for its streaks and history.'], ['How is focus time counted?', 'Only the time a timer actually ran. Pausing stops the clock, and closing the app does not add time.'], ['How do I plan for an exam?', 'Open Exam AI, add an exam, add its topics, then tap Generate plan. Turn on Show plan in My Day to see sessions in your planner.'], ['Will I lose my data?', 'Data is stored on this phone. Use Export my data in the Control Center for backups.']].map(q => `<div class="card" style="margin-bottom:10px"><b>${q[0]}</b><p class="mut" style="margin-top:6px;line-height:1.5">${q[1]}</p></div>`).join('')}`;
SCREENS.about = () => `${hdr('About', '')}<div class="center" style="height:auto;padding:30px 0"><div class="logo big">AARZOO</div><p class="mut">Plan. Focus. Achieve.</p><small>Version 1.0.0</small></div><div class="card" style="line-height:1.55"><p>AARZOO is a student planner that brings your daily schedule, habits, notes, focus sessions and exam preparation into one place.</p></div>`;
