'use strict';
/* Exam planner. Plans are produced by a rule-based scheduling algorithm that runs on the device.
   No AI service is connected, and the screens say so. */
const PRI = { low: 1, medium: 2, high: 3 };
const DIFF = ['', 'Easy', 'Medium', 'Hard'];
const DIFFMIN = { 1: 45, 2: 60, 3: 90 };
const examDays = e => Math.round((pd(e.date) - pd(today())) / 864e5);
const examPct = e => e.topics.length ? Math.round(e.topics.filter(t => t.done).length / e.topics.length * 100) : 0;
const prepEst = e => e.topics.length ? Math.round((e.topics.filter(t => t.done).length * 0.7 + e.topics.filter(t => t.revised).length * 0.3) / e.topics.length * 100) : 0;

SCREENS.exams = () => {
  const tabs = [['plan', 'Exams'], ['timeline', 'Timeline'], ['matrix', 'Matrix'], ['stats', 'Analytics']];
  const body = R.examTab === 'plan' ? examList() : R.examTab === 'timeline' ? examTimeline() : R.examTab === 'matrix' ? examMatrix() : examStats();
  return `${hdr('AI Exam Planner', 'Auto-timelines and matrices for your exams', `<button class="ib big" data-a="addexam">${ic('plus')}</button>`)}
  <div class="info-note">Plans are built by a scheduling algorithm on your phone using your exam dates, topic difficulty, prep level and free time. No AI service is connected yet. Exam dates and syllabus are whatever you enter.</div>
  <div class="seg">${tabs.map(t => `<button class="${R.examTab === t[0] ? 'on' : ''}" data-a="examtab" data-t="${t[0]}">${t[1]}</button>`).join('')}</div>${body}`;
};
A.examtab = el => { R.examTab = el.dataset.t; render(true); };

function examList() {
  const ex = D.exams.slice().sort((a, b) => a.date.localeCompare(b.date));
  return `<div class="two" style="margin-bottom:14px"><button class="btn pri" data-a="genplan">${ic('cpu', 18)} Generate plan</button><button class="btn" data-a="plancfg">${ic('sliders', 18)} Plan settings</button></div>
  <div class="card row between" style="margin-bottom:14px"><div><b>Show plan in My Day</b><small style="display:block;margin-top:2px">Study sessions appear in your daily planner</small></div><button class="sw2 ${D.planInDay ? 'on' : ''}" data-a="planday"></button></div>
  ${ex.length ? ex.map(e => { const d = examDays(e); return `<button class="li" style="--c:${DCOL[e.priority] || '#8B36F5'}" data-a="go" data-to="push:exam" data-p="${gop({ id: e.id })}"><div class="grow"><b>${esc(e.name)}</b><small>${esc(e.subject)} · ${fmtD(e.date)}${e.time ? ', ' + fmtT(e.time) : ''}</small><div class="bar" style="margin-top:8px"><i style="width:${examPct(e)}%;--c:#8B36F5"></i></div><small>${e.topics.length ? examPct(e) + '% of ' + e.topics.length + ' topics studied' : 'No topics added yet'}</small></div><span class="tag ${d < 0 ? 'red' : d <= 7 ? 'ye' : ''}">${d < 0 ? 'Over' : d === 0 ? 'Today' : d + 'd'}</span></button>`; }).join('') : empty('No exams yet', 'Tap + to add an exam, then add its syllabus topics.', 'book')}`;
}
A.planday = () => { D.planInDay = !D.planInDay; save(); render(true); toast(D.planInDay ? 'Study sessions now show in My Day' : 'Study sessions hidden from My Day'); };
A.addexam = () => examForm(null);
function examForm(e0) {
  const e = e0 || { date: addDays(today(), 14), time: '10:00', prep: 3, priority: 'medium', hours: 3 };
  formSheet(e0 ? 'Edit exam' : 'New exam', F.t('Exam name *', 'name', e.name, 'e.g. Mid-term 1') + F.t('Subject *', 'subject', e.subject, 'e.g. Data Structures', 'list="subjl"') + `<datalist id="subjl">${subjectsList().map(s => `<option value="${esc(s)}">`).join('')}</datalist>` + F.d('Exam date', 'date', e.date) + F.tm('Exam time', 'time', e.time) +
    F.s('Preparation level', 'prep', [[1, '1 - Just starting'], [2, '2 - Some basics'], [3, '3 - Halfway'], [4, '4 - Mostly ready'], [5, '5 - Revision only']], e.prep) + F.s('Priority', 'priority', [['low', 'Low'], ['medium', 'Medium'], ['high', 'High']], e.priority) + F.num('Study hours available per day', 'hours', e.hours, '', 'min="0.5" max="12" step="0.5"'),
    v => {
      if (!v.name.trim()) return 'Exam name is required.'; if (!v.subject.trim()) return 'Subject is required.';
      if (!validDate(v.date)) return 'Pick a valid exam date.'; const h = Number(v.hours); if (!(h >= 0.5 && h <= 12)) return 'Study hours must be between 0.5 and 12.';
      const o = { name: v.name.trim(), subject: v.subject.trim(), date: v.date, time: v.time, prep: +v.prep, priority: v.priority, hours: h };
      if (e0) Object.assign(e0, o); else D.exams.push({ id: uid(), topics: [], ...o });
      save(); closeSheet(); toast(e0 ? 'Exam updated' : 'Exam added'); render(true); scheduleSoon();
    }, { onDel: e0 ? () => delExam(e0.id) : null });
}
function delExam(id) { confirmBox('Delete exam?', 'Its syllabus and study sessions will be removed.', () => { D.exams = D.exams.filter(e => e.id !== id); D.plan = D.plan.filter(s => s.examId !== id); save(); closeSheet(); if (curScreen().name === 'exam') R.stack.pop(); render(); toast('Exam deleted'); scheduleSoon(); }); }

/* ---------- exam detail: syllabus ---------- */
SCREENS.exam = p => {
  const e = D.exams.find(x => x.id === p.id); if (!e) return hdr('Exam') + empty('Exam not found', '', 'book');
  const ch = {}; e.topics.forEach(t => (ch[t.chapter || 'General'] = ch[t.chapter || 'General'] || []).push(t));
  const d = examDays(e);
  return `${hdr(esc(e.name), esc(e.subject), `<button class="ib" data-a="editexam" data-id="${e.id}">${ic('edit', 18)}</button><button class="ib red" data-a="delexam" data-id="${e.id}">${ic('trash', 18)}</button>`)}
  <div class="card"><div class="row between"><div><b style="font-size:20px">${d < 0 ? 'Exam date has passed' : d === 0 ? 'Exam is today' : d + ' days left'}</b><small style="display:block;margin-top:4px">${fmtD(e.date, { weekday: 'long', month: 'long', day: 'numeric' })}${e.time ? ', ' + fmtT(e.time) : ''}</small></div>${ring(examPct(e), 70, `<span style="font-size:15px">${examPct(e)}%</span>`, '#8B36F5')}</div>
  <div style="margin-top:10px;font-size:13px" class="mut">Prep level ${e.prep}/5 · ${e.hours} h/day · ${esc(e.priority)} priority</div></div>
  <div class="two" style="margin:14px 0"><button class="btn pri" data-a="addtopic" data-id="${e.id}">${ic('plus', 18)} Add topic</button><button class="btn" data-a="alldone" data-id="${e.id}">${ic('check', 18)} Mark all studied</button></div>
  ${e.topics.length ? Object.keys(ch).map(c => `<div class="cap">${esc(c).toUpperCase()}</div>${ch[c].map(t => `<div class="li" style="--c:${t.done ? '#20D6A5' : '#8B36F5'}"><button class="cbx ${t.done ? 'on' : ''}" style="--c:#20D6A5" data-a="topicdone" data-e="${e.id}" data-t="${t.id}" aria-label="Studied">${t.done ? ic('check', 15) : ''}</button><div class="grow" data-a="topicedit" data-e="${e.id}" data-t="${t.id}"><b class="${t.done ? 'strike' : ''}">${esc(t.name)}</b><small>${DIFF[t.diff]} · ${dur(t.mins)}${t.revised ? ' · revised' : ''}${t.notes ? ' · ' + esc(t.notes.slice(0, 30)) : ''}</small></div><button class="ib sm" data-a="topicedit" data-e="${e.id}" data-t="${t.id}">${ic('edit', 14)}</button></div>`).join('')}`).join('') : empty('No syllabus yet', 'Add chapters and topics so the planner can schedule them.', 'list')}`;
};
A.editexam = el => examForm(D.exams.find(e => e.id === el.dataset.id));
A.delexam = el => delExam(el.dataset.id);
A.alldone = el => confirmBox('Mark everything studied?', 'All topics in this exam will be ticked as studied.', () => { const e = D.exams.find(x => x.id === el.dataset.id); e.topics.forEach(t => t.done = true); save(); render(true); }, 'Mark all');
A.topicdone = el => { const e = D.exams.find(x => x.id === el.dataset.e), t = e.topics.find(x => x.id === el.dataset.t); t.done = !t.done; save(); render(true); };
A.addtopic = el => topicForm(D.exams.find(e => e.id === el.dataset.id), null);
A.topicedit = el => { const e = D.exams.find(x => x.id === el.dataset.e); topicForm(e, e.topics.find(t => t.id === el.dataset.t)); };
function topicForm(e, t) {
  const o0 = t || { diff: 2, chapter: (e.topics[e.topics.length - 1] || {}).chapter || '' };
  formSheet(t ? 'Edit topic' : 'New topic', F.t('Chapter', 'chapter', o0.chapter, 'e.g. Unit 1 - Arrays') + F.t('Topic *', 'name', o0.name, 'e.g. Binary search') + F.s('Difficulty', 'diff', [[1, 'Easy'], [2, 'Medium'], [3, 'Hard']], o0.diff) + F.num('Estimated study time (minutes)', 'mins', o0.mins, 'Leave blank for a default', 'min="15" step="5"') + F.a('Personal notes', 'notes', o0.notes) + (t ? `<label class="row"><input type="checkbox" name="revised" ${t.revised ? 'checked' : ''}> <span>Revision done</span></label>` : ''),
    v => {
      if (!v.name.trim()) return 'Topic name is required.';
      const diff = +v.diff, m = v.mins === '' ? DIFFMIN[diff] : Number(v.mins); if (!(m >= 15 && m <= 600)) return 'Study time must be between 15 and 600 minutes.';
      const o = { chapter: v.chapter.trim(), name: v.name.trim(), diff, mins: Math.round(m), notes: v.notes.trim() };
      if (t) { Object.assign(t, o); t.revised = !!v.revised; } else e.topics.push({ id: uid(), done: false, revised: false, ...o });
      save(); closeSheet(); render(true); toast(t ? 'Topic updated' : 'Topic added');
    }, { onDel: t ? () => { e.topics = e.topics.filter(x => x.id !== t.id); D.plan = D.plan.filter(s => s.topicId !== t.id); save(); closeSheet(); render(true); toast('Topic deleted'); } : null });
}

/* ---------- plan settings ---------- */
A.plancfg = () => {
  const c = D.planCfg;
  sheet(`<div class="sh-h"><b>Plan settings</b><button class="ib sm" data-a="sheetclose">${ic('x', 18)}</button></div><div class="sh-b" id="frm">${F.tm('Daily study start time', 'start', c.start)}<div class="fl"><span>Unavailable dates (no study sessions)</span>${c.unavail.length ? c.unavail.map(d => `<div class="kv"><b>${fmtD(d, { weekday: 'short', month: 'short', day: 'numeric' })}</b><button class="link" data-a="unrm" data-d="${d}">Remove</button></div>`).join('') : '<small>None</small>'}</div><div class="row">${`<input class="inp" type="date" name="un" style="flex:1">`}<button class="btn" data-a="unadd">Add</button></div><div class="err" id="ferr"></div></div><div class="sh-f"><button class="btn" data-a="sheetclose">Cancel</button><button class="btn pri" data-a="plancfgsave">Save</button></div>`);
};
A.unadd = () => { const v = $('#frm input[name=un]').value; if (!validDate(v)) return $('#ferr').textContent = 'Pick a date to add.'; if (!D.planCfg.unavail.includes(v)) D.planCfg.unavail.push(v); D.planCfg.unavail.sort(); save(); A.plancfg(); };
A.unrm = el => { D.planCfg.unavail = D.planCfg.unavail.filter(d => d !== el.dataset.d); save(); A.plancfg(); };
A.plancfgsave = () => { const s = $('#frm input[name=start]').value; if (!validTime(s)) return $('#ferr').textContent = 'Pick a start time.'; D.planCfg.start = s; save(); closeSheet(); toast('Settings saved'); };

/* ---------- plan generator (rule-based) ---------- */
function genPlan() {
  const t0 = today(), cfg = D.planCfg, nowM = new Date().getHours() * 60 + new Date().getMinutes();
  D.plan = D.plan.filter(s => s.done);
  const exams = D.exams.filter(e => e.date > t0).sort((a, b) => a.date.localeCompare(b.date) || PRI[b.priority] - PRI[a.priority]);
  if (!exams.length) return { n: 0, warn: 'Add an exam with a future date first.' };
  const st = exams.map(e => {
    const f = [1.2, 1.1, 1, .85, .7][(e.prep || 3) - 1], days = [];
    for (let d = t0; d < e.date; d = addDays(d, 1)) if (!cfg.unavail.includes(d)) days.push(d);
    const rev = days.length >= 4 ? Math.max(1, Math.round(days.length * .25)) : 0;
    return { e, days, revFrom: days.length - rev, study: e.topics.filter(t => !t.done).map(t => ({ id: t.id, rem: Math.max(15, Math.round(t.mins * f / 5) * 5) })), rev: e.topics.filter(t => !t.revised).map(t => ({ id: t.id, rem: Math.max(15, Math.round(t.mins * f * .4 / 5) * 5) })), w: PRI[e.priority] || 2 };
  });
  const last = st.reduce((m, s) => s.e.date > m ? s.e.date : m, t0);
  let n = 0;
  for (let d = t0; d < last; d = addDays(d, 1)) {
    const act = st.filter(s => s.days.includes(d)); if (!act.length) continue;
    const busy = tasksOnNoPlan(d).map(t => [mins(t.start), mins(t.end)]);
    const cap = Math.max(...act.map(s => s.e.hours)) * 60, sw = act.reduce((a, s) => a + s.w, 0);
    let cur = Math.max(mins(cfg.start), d === t0 ? Math.ceil((nowM + 15) / 5) * 5 : 0);
    const day = [];
    for (const s of act) {
      let share = cap * s.w / sw; const idx = s.days.indexOf(d);
      while (share >= 15) {
        const useRev = (idx >= s.revFrom && s.rev.length) || !s.study.length, q = useRev ? s.rev : s.study;
        if (!q.length) break;
        const it = q[0], chunk = Math.min(it.rem, 90, Math.floor(share / 5) * 5); if (chunk < 15 && it.rem > chunk) break;
        let a = cur, moved = true;
        while (moved) { moved = false; for (const [bs, be] of busy) if (a < be && a + chunk > bs) { a = Math.ceil((be + 5) / 5) * 5; moved = true; } }
        if (a + chunk > 1410) break;
        day.push({ id: uid(), examId: s.e.id, topicId: it.id, type: useRev ? 'revision' : 'study', date: d, start: hm(a), end: hm(a + chunk), mins: chunk, done: false });
        n++; it.rem -= chunk; if (it.rem <= 0) q.shift(); share -= chunk; cur = a + chunk + 10;
      }
    }
    D.plan.push(...day);
  }
  const left = st.reduce((a, s) => a + s.study.length, 0);
  save(); scheduleSoon();
  return { n, warn: left ? left + ' topic' + (left > 1 ? 's' : '') + " didn't fit before the exam dates. Add study hours, free up days, or reduce topics." : '' };
}
const tasksOnNoPlan = d => D.tasks.filter(t => occurs(t, d));
A.genplan = () => {
  if (!D.exams.some(e => e.topics.length)) return toast('Add syllabus topics to an exam first', true);
  const go = () => { const r = genPlan(); R.examTab = 'timeline'; render(true); toast(r.n ? r.n + ' study sessions planned' : (r.warn || 'Nothing to plan'), !r.n); if (r.n && r.warn) setTimeout(() => toast(r.warn, true), 2600); };
  if (D.plan.some(s => !s.done)) confirmBox('Regenerate plan?', 'Unfinished sessions are replaced. Sessions you completed stay. Missed sessions are rescheduled.', go, 'Regenerate'); else go();
};

/* ---------- timeline ---------- */
function examTimeline() {
  const byDay = {}; D.plan.forEach(s => (byDay[s.date] = byDay[s.date] || []).push(s));
  const days = Object.keys(byDay).sort(), t = today();
  if (!days.length) return empty('No study plan yet', 'Add exams with topics, then tap Generate plan on the Exams tab.', 'cal');
  return `<div class="row" style="margin-bottom:12px"><button class="btn sm" data-a="genplan">${ic('refresh', 16)} Regenerate / reschedule missed</button><button class="btn sm" data-a="addsess">${ic('plus', 16)} Session</button></div>` + days.map(d => {
    const ss = byDay[d].sort((a, b) => a.start.localeCompare(b.start)), tot = ss.reduce((a, s) => a + s.mins, 0);
    return `<div class="cap" style="margin-top:18px">${fmtD(d, { weekday: 'long', month: 'short', day: 'numeric' }).toUpperCase()}${d === t ? ' · TODAY' : ''}</div><small style="display:block;margin:-6px 4px 10px">Daily target: ${ss.length} session${ss.length > 1 ? 's' : ''}, ${dur(tot)}</small>` +
      ss.map((s, i) => { const e = D.exams.find(x => x.id === s.examId), tp = e && e.topics.find(x => x.id === s.topicId), gap = i && mins(s.start) - mins(ss[i - 1].end);
        return (gap >= 5 ? `<small style="display:block;margin:0 0 8px 20px">Break · ${gap} min</small>` : '') + `<div class="li" style="--c:${s.type === 'revision' ? '#FFD166' : '#8B36F5'}"><button class="cbx ${s.done ? 'on' : ''}" style="--c:#20D6A5" data-a="sessdone" data-id="${s.id}">${s.done ? ic('check', 15) : ''}</button><div class="grow" data-a="sessedit" data-id="${s.id}"><b class="${s.done ? 'strike' : ''}">${esc(e ? e.subject : '')} - ${esc(tp ? tp.name : 'Topic removed')}</b><small>${fmtT(s.start)} - ${fmtT(s.end)} · ${dur(s.mins)} · ${s.type === 'revision' ? 'Revision' : 'Study'}${d < t && !s.done ? ' · missed' : ''}</small></div><button class="ib sm" data-a="sessedit" data-id="${s.id}">${ic('edit', 14)}</button></div>`; }).join('');
  }).join('');
}
A.sessdone = el => { const s = D.plan.find(x => x.id === el.dataset.id); toggleTask({ planId: s.id }); render(true); };
A.addsess = () => sessForm(null);
A.sessedit = el => sessForm(D.plan.find(x => x.id === el.dataset.id));
function sessForm(s) {
  const tops = []; D.exams.forEach(e => e.topics.forEach(t => tops.push([e.id + '|' + t.id, e.subject + ' - ' + t.name])));
  if (!s && !tops.length) return toast('Add syllabus topics first', true);
  const e = s || { date: today(), start: D.planCfg.start, end: hm(mins(D.planCfg.start) + 60), type: 'study' };
  formSheet(s ? 'Edit session' : 'New session', F.s('Topic', 'topic', tops, s ? s.examId + '|' + s.topicId : tops[0][0]) + F.s('Type', 'type', [['study', 'Study'], ['revision', 'Revision']], e.type) + F.d('Date', 'date', e.date) + `<div class="two">${F.tm('Start', 'start', e.start)}${F.tm('End', 'end', e.end)}</div>`,
    v => {
      if (!validDate(v.date)) return 'Pick a valid date.'; if (!validTime(v.start) || !validTime(v.end)) return 'Pick start and end times.'; if (mins(v.end) <= mins(v.start)) return 'End time must be later than start time.';
      const [ex, tp] = v.topic.split('|'), o = { examId: ex, topicId: tp, type: v.type, date: v.date, start: v.start, end: v.end, mins: mins(v.end) - mins(v.start) };
      if (s) Object.assign(s, o); else D.plan.push({ id: uid(), done: false, ...o });
      save(); closeSheet(); render(true); toast(s ? 'Session updated' : 'Session added'); scheduleSoon();
    }, { onDel: s ? () => { D.plan = D.plan.filter(x => x.id !== s.id); save(); closeSheet(); render(true); toast('Session deleted'); } : null });
}

/* ---------- matrix & analytics ---------- */
function examMatrix() {
  if (!D.exams.length) return empty('No exams yet', 'Add an exam and its topics to see the matrix.', 'grid');
  return D.exams.map(e => `<div class="card" style="margin-bottom:14px"><div class="row between"><b>${esc(e.subject)}</b><span class="tag">${examPct(e)}% studied</span></div><div class="scrollx"><table class="mx"><tr><th>Chapter</th><th>Topic</th><th>Level</th><th>Study</th><th>Revise</th></tr>${e.topics.length ? e.topics.map(t => `<tr><td>${esc(t.chapter || '-')}</td><td>${esc(t.name)}</td><td>${DIFF[t.diff]}</td><td><button class="cbx ${t.done ? 'on' : ''}" style="--c:#20D6A5;width:26px;height:26px" data-a="topicdone" data-e="${e.id}" data-t="${t.id}">${t.done ? ic('check', 13) : ''}</button></td><td><button class="cbx ${t.revised ? 'on' : ''}" style="--c:#FFD166;width:26px;height:26px" data-a="toprev" data-e="${e.id}" data-t="${t.id}">${t.revised ? ic('check', 13) : ''}</button></td></tr>`).join('') : '<tr><td colspan="5" class="mut">No topics yet</td></tr>'}</table></div></div>`).join('');
}
A.toprev = el => { const e = D.exams.find(x => x.id === el.dataset.e), t = e.topics.find(x => x.id === el.dataset.t); t.revised = !t.revised; save(); render(true); };
function examStats() {
  if (!D.exams.length) return empty('No exam data yet', 'Add exams and topics to see progress.', 'bars');
  const all = D.exams.flatMap(e => e.topics), tot = all.length, done = all.filter(t => t.done).length, rev = all.filter(t => t.revised).length;
  const up = D.exams.filter(e => examDays(e) >= 0).sort((a, b) => a.date.localeCompare(b.date))[0];
  return `<div class="card"><div class="row" style="gap:16px">${ring(tot ? Math.round(done / tot * 100) : 0, 96, `<span>${tot ? Math.round(done / tot * 100) : 0}%</span>`, '#8B36F5')}<div class="grow">${kv('Topics studied', done + ' / ' + tot)}${kv('Topics remaining', tot - done)}${kv('Revision done', rev + ' / ' + tot)}${kv('Next exam in', up ? examDays(up) + ' days' : '-')}</div></div></div>
  <div class="cap">BY SUBJECT</div>${D.exams.map(e => `<div class="card" style="margin-bottom:10px"><div class="row between"><b>${esc(e.subject)}</b><small>${examDays(e) < 0 ? 'exam passed' : examDays(e) + ' days left'}</small></div><div class="bar" style="margin:10px 0 6px"><i style="width:${examPct(e)}%;--c:#8B36F5"></i></div><small>Studied ${examPct(e)}% · Estimated readiness ${prepEst(e)}% · ${e.topics.filter(t => !t.done).length} topics left</small></div>`).join('')}
  <p class="mut" style="font-size:12px;line-height:1.5">Readiness is calculated from the topics you tick (70% studied, 30% revised). It is an estimate, not a prediction of your marks.</p>`;
}
