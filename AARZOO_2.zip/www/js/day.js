'use strict';
const splitT = s => { const i = s.lastIndexOf(' '); return i < 0 ? [s, ''] : [s.slice(0, i), s.slice(i + 1)]; };

SCREENS.day = () => {
  const dt = pd(R.sel), mo = dt.toLocaleDateString([], { month: 'short', year: 'numeric' });
  const right = R.dayMode === 'habits' ? `<div class="streak">${maxStreak()} 🔥</div>` : `<button class="ib big" data-a="seltoday">${ic('clock')}</button>`;
  return `<div class="hd"><div class="hd-t"><div class="mrow"><button class="ib sm" data-a="mshift" data-n="-1">${ic('back', 16)}</button><h1>${mo}</h1><button class="ib sm" data-a="mshift" data-n="1">${ic('chev', 16)}</button></div><p>Manage your schedule</p></div><div class="hd-r">${right}<button class="ib big" data-a="pickdate">${ic('cal')}</button></div></div>
  <div class="tabs2"><button class="${R.dayMode === 'planner' ? 'on' : ''}" data-a="daymode" data-m="planner">${ic('list', 18)} Daily Planner</button><button class="${R.dayMode === 'habits' ? 'on' : ''}" data-a="daymode" data-m="habits">${ic('grid', 18)} Habit Matrix</button></div>
  ${dateStrip('rect')}${R.dayMode === 'planner' ? timeline() : habitMatrix()}
  <button class="fab" data-a="${R.dayMode === 'planner' ? 'addtask' : 'addhabit'}">${ic('plus', 28)}</button>`;
};
A.daymode = el => { R.dayMode = el.dataset.m; render(true); };
A.seltoday = () => { R.sel = today(); render(true); };
A.mshift = el => {
  const d = pd(R.sel), day = d.getDate(); d.setDate(1); d.setMonth(d.getMonth() + Number(el.dataset.n));
  d.setDate(Math.min(day, new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate())); R.sel = ymd(d); render(true);
};
A.pickdate = () => formSheet('Go to date', F.d('Date', 'date', R.sel), v => { if (!validDate(v.date)) return 'Pick a valid date.'; R.sel = v.date; closeSheet(); render(); }, { saveLabel: 'Go' });

function timeline() {
  const ts = tasksOn(R.sel);
  if (!ts.length) return empty('Nothing planned for ' + fmtD(R.sel, { weekday: 'long' }), 'Tap + to add a task to this day.', 'cal');
  return `<div class="tl">${ts.map(t => {
    const st = tstatus(t), c = t.color || '#08D9F2', sp = splitT(fmtT(t.start));
    return `<div class="tl-r"><div class="tl-t"><b>${esc(sp[0])}</b><small>${esc(sp[1])}</small></div>
    <div class="tl-m"><button class="dot ${st}" style="--c:${c}" data-a="tt" data-id="${t.id}" data-occ="${t.occ}" aria-label="Toggle complete">${st === 'done' ? ic('check', 12) : ''}</button><i></i></div>
    <div class="tcard ${st}" style="--c:${c}" data-a="td" data-id="${t.id}" data-occ="${t.occ}"><b class="${st === 'done' ? 'strike' : ''}">${esc(t.title)}</b><span>${ic('clock', 14)} ${fmtT(t.start)} - ${fmtT(t.end)} · ${dur(mins(t.end) - mins(t.start))}</span>${t.subject ? `<small>${esc(t.subject)}</small>` : ''}${st === 'overdue' ? '<em class="tag red" style="align-self:flex-start">Overdue</em>' : st === 'active' ? '<em class="tag" style="align-self:flex-start">Happening now</em>' : ''}</div></div>`;
  }).join('')}</div>`;
}

/* ---------- habit matrix ---------- */
function habitMatrix() {
  const hs = D.habits;
  if (!hs.length) return empty('No habits yet', 'Tap + to add a habit and start a streak.', 'bolt');
  const days = [...Array(14)].map((_, i) => addDays(R.sel, -i)), t = today();
  return `<div class="hm"><div class="hm-s"><div class="hm-h">HABITS</div>${hs.map(h => `<button class="hm-n" data-a="hd" data-id="${h.id}"><b>${esc(h.icon || '')} ${esc(h.name)}</b><small style="color:${h.color}">WINS: ${streak(h).total}${h.paused ? ' · PAUSED' : ''}</small></button>`).join('')}</div>
  <div class="hm-sc"><div class="hm-row hm-hd">${days.map(d => `<div class="hm-c ${d === t ? 'tod' : ''}"><small>${d === t ? 'Today' : 'SMTWTFS'[dow(d)]}</small><b>${pd(d).getDate()}</b></div>`).join('')}</div>
  ${hs.map(h => `<div class="hm-row">${days.map(d => hcell(h, d)).join('')}</div>`).join('')}</div></div>
  <p class="mut" style="font-size:13px;margin-top:12px;text-align:center">Tap a box to tick it. Scroll sideways for earlier days. Tap a habit name for its history.</p>`;
}
function hcell(h, d) {
  const on = (D.habitLog[h.id] || {})[d], t = today();
  if (d > t) return `<div class="hm-c"><i class="hb dis"></i></div>`;
  if (!on && (d < h.start || h.paused || !sched(h, d))) return `<div class="hm-c"><i class="hb off">-</i></div>`;
  return `<div class="hm-c"><button class="hb ${on ? 'on' : ''}" style="--c:${h.color}" data-a="hc" data-id="${h.id}" data-d="${d}" aria-label="Toggle habit">${on ? ic('check', 22) : ''}</button></div>`;
}
A.hc = el => {
  const id = el.dataset.id, d = el.dataset.d; D.habitLog[id] = D.habitLog[id] || {};
  if (D.habitLog[id][d]) delete D.habitLog[id][d]; else D.habitLog[id][d] = 1;
  save(); render(true); scheduleSoon();
};
const HICONS = ['', '📖', '😴', '📝', '🧴', '🚶', '💧', '🏃', '🧘', '🍎', '💻', '🎯'];
A.addhabit = () => habitForm(null);
function habitForm(h) {
  const e = h || { color: '#F52C79', freq: 'daily', days: [1, 2, 3, 4, 5], start: today(), icon: '', reminder: '' };
  formSheet(h ? 'Edit habit' : 'New habit',
    F.t('Habit name *', 'name', e.name, 'e.g. Book reading') + F.a('Description', 'desc', e.desc) + F.s('Icon', 'icon', HICONS.map(i => [i, i || 'None']), e.icon) + F.col('color', e.color) +
    F.s('Frequency', 'freq', [['daily', 'Every day'], ['custom', 'Selected days']], e.freq) + F.days(e.days) + F.tm('Reminder time (optional)', 'reminder', e.reminder) + F.d('Start date', 'start', e.start) + F.t('Daily target (optional)', 'target', e.target, 'e.g. 20 pages'),
    v => {
      if (!v.name.trim()) return 'Habit name is required.';
      if (!validDate(v.start)) return 'Pick a valid start date.';
      const dd = pickDays(v); if (v.freq === 'custom' && !dd.length) return 'Select at least one day.';
      const o = { name: v.name.trim(), desc: v.desc.trim(), icon: v.icon, color: v.color, freq: v.freq, days: dd, reminder: v.reminder, start: v.start, target: v.target.trim() };
      if (h) Object.assign(h, o); else D.habits.push({ id: uid(), paused: false, created: Date.now(), ...o });
      save(); closeSheet(); toast(h ? 'Habit updated' : 'Habit added'); render(true); scheduleSoon();
    }, { onDel: h ? () => delHabit(h.id) : null });
}
function delHabit(id) { confirmBox('Delete habit?', 'Its whole history will be removed.', () => { D.habits = D.habits.filter(h => h.id !== id); delete D.habitLog[id]; save(); closeSheet(); toast('Habit deleted'); render(true); scheduleSoon(); }); }
A.hd = el => habitDetail(D.habits.find(h => h.id === el.dataset.id));
function habitDetail(h) {
  if (!h) return;
  const s = streak(h), log = Object.keys(D.habitLog[h.id] || {}).sort().reverse().slice(0, 14);
  infoSheet((h.icon || '') + ' ' + h.name,
    `<div class="row" style="margin-bottom:8px">${h.paused ? '<span class="tag ye">PAUSED</span>' : '<span class="tag gr">ACTIVE</span>'}</div>` + kv('Current streak', s.cur + ' days') + kv('Longest streak', s.best + ' days') + kv('Total completions', s.total) + kv('Last 30 days', habitPct(h, 30) + '%') +
    kv('Schedule', h.freq === 'daily' ? 'Every day' : (h.days || []).map(i => 'SMTWTFS'[i]).join(' ')) + kv('Daily target', esc(h.target)) + kv('Reminder', h.reminder ? fmtT(h.reminder) : '') + kv('Started', fmtD(h.start, { month: 'short', day: 'numeric', year: 'numeric' })) + kv('Description', esc(h.desc)) +
    `<h3 style="margin:16px 0 6px;font-size:15px">Recent history</h3>${log.length ? log.map(d => `<div class="kv"><span>${fmtD(d, { weekday: 'short', month: 'short', day: 'numeric' })}</span><b style="color:${h.color}">Done</b></div>`).join('') : '<p class="mut" style="font-size:14px">No completions yet.</p>'}`,
    `<button class="btn" data-a="hpause" data-id="${h.id}">${h.paused ? 'Resume' : 'Pause'}</button><button class="btn pri" data-a="hedit" data-id="${h.id}">Edit</button>`);
}
A.hpause = el => { const h = D.habits.find(x => x.id === el.dataset.id); h.paused = !h.paused; save(); closeSheet(); toast(h.paused ? 'Habit paused' : 'Habit resumed'); render(true); scheduleSoon(); };
A.hedit = el => habitForm(D.habits.find(x => x.id === el.dataset.id));
