'use strict';
const PAL = ['#08D9F2', '#258BFF', '#8B36F5', '#F52C79', '#20D6A5', '#FFD166', '#FF8A3D', '#FF536B'];
const PAL2 = ['#08D9F2', '#20D6A5', '#FFD166', '#FF536B', '#8B36F5', '#FFFFFF', '#F59E0B', '#EC4899', '#8B5CF6', '#3B82F6', '#14B8A6', '#F43F5E', '#A855F7', '#D946EF', '#EAB308', '#06B6D4'];
const ICONS = {
  grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  cal: '<rect x="3" y="4" width="18" height="18" rx="3"/><path d="M16 2v4M8 2v4M3 10h18"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  chat: '<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/>',
  back: '<path d="M19 12H5M11 6l-6 6 6 6"/>',
  share: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.6 10.5l6.8-4M8.6 13.5l6.8 4"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2 20c0-3.5 3-6 7-6s7 2.5 7 6"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M18 14c2.5.6 4 2.5 4 5"/>',
  userplus: '<circle cx="9" cy="8" r="3.5"/><path d="M2 20c0-3.5 3-6 7-6s7 2.5 7 6M19 8v6M16 11h6"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
  cpu: '<rect x="6" y="6" width="12" height="12" rx="2"/><rect x="10" y="10" width="4" height="4"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/>',
  bolt: '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
  brief: '<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M9 7V4h6v3M3 13h18"/>',
  pulse: '<path d="M3 12h4l3-8 4 16 3-8h4"/>',
  alert: '<circle cx="12" cy="12" r="9"/><path d="M12 7v6M12 16.5v.01"/>',
  camera: '<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
  sliders: '<path d="M4 6h10M18 6h2M4 12h2M10 12h10M4 18h12M20 18h0"/><circle cx="16" cy="6" r="2"/><circle cx="8" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  chev: '<path d="M9 6l6 6-6 6"/>',
  chevd: '<path d="M6 9l6 6 6-6"/>',
  flame: '<path d="M12 3c1 4 5 5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-5 1-9z"/>',
  drop: '<path d="M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11z"/>',
  play: '<path d="M7 4l13 8-13 8z"/>',
  pause: '<path d="M8 5v14M16 5v14"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="2"/>',
  refresh: '<path d="M20 11a8 8 0 0 0-14-4L4 9M4 4v5h5M4 13a8 8 0 0 0 14 4l2-2M20 20v-5h-5"/>',
  file: '<path d="M6 3h8l5 5v13H6z"/><path d="M14 3v5h5"/>',
  bars: '<path d="M6 20V10M12 20V4M18 20v-7"/>',
  logout: '<path d="M9 4H5v16h4M16 8l4 4-4 4M20 12H9"/>',
  bell: '<path d="M6 17V11a6 6 0 0 1 12 0v6l2 2H4zM10 21h4"/>',
  pin: '<path d="M12 17v5M8 3h8l-1 7 3 3H6l3-3z"/>',
  download: '<path d="M12 3v12M7 11l5 5 5-5M4 21h16"/>',
  upload: '<path d="M12 16V4M7 8l5-5 5 5M4 21h16"/>',
  help: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 1 1 3.5 2.3c-.7.4-1 1-1 1.7M12 17v.01"/>',
  lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  palette: '<circle cx="12" cy="12" r="9"/><circle cx="8" cy="10" r="1"/><circle cx="12" cy="7" r="1"/><circle cx="16" cy="10" r="1"/>',
  book: '<path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z"/><path d="M4 21V5"/>',
  copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>'
};
const ic = (n, s = 22) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${ICONS[n] || ''}</svg>`;

/* ---------- state / router ---------- */
const R = { tab: 'home', stack: [], sel: null, auth: null, dayMode: 'planner', examTab: 'plan', focusRange: 'today', fFrom: '', fTo: '', vq: '', leave: null, ob: 0, anTab: 'week', ntab: 'n' };
const SCREENS = {}, AFTER = {}, A = {};
const cap = n => window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins[n];
const isNative = () => !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
const NAV = [['home', 'grid', 'Home'], ['day', 'cal', 'My Day'], ['vault', 'folder', 'Vault'], ['focus', 'target', 'Focus'], ['profile', 'user', 'Profile']];

function nav(tab) { closeAll(); R.leave = null; R.tab = tab; R.stack = []; render(); }
function push(name, p) { R.stack.push({ name, p: p || {} }); render(); const v = $('#view'); if (v) v.scrollTop = 0; }
function pop() {
  if ($('#dlgRoot').firstChild) { A.cbno(); return true; }
  if ($('#sheetRoot').firstChild) { closeSheet(); return true; }
  if (R.auth) { if (R.auth === 'signup' || R.auth === 'forgot') { R.auth = 'login'; renderAuth(); return true; } return false; }
  if (R.leave) { const f = R.leave; R.leave = null; f(); }
  if (R.stack.length) { R.stack.pop(); render(); return true; }
  if (R.tab !== 'home') { nav('home'); return true; }
  return false;
}
A.back = () => pop();
function closeAll() { $('#sheetRoot').innerHTML = ''; $('#dlgRoot').innerHTML = ''; }
function curScreen() { return R.stack.length ? R.stack[R.stack.length - 1] : { name: R.tab, p: {} }; }
function render(keep) {
  if (!D) return;
  const cur = curScreen(), old = $('#view'), sc = keep && old ? old.scrollTop : 0;
  const full = R.stack.length > 0 || false;
  const body = SCREENS[cur.name] ? SCREENS[cur.name](cur.p) : '';
  const bare = ['timer'].includes(cur.name);
  $('#app').innerHTML = bare ? body : `<div id="view" class="view ${full ? 'nonav' : ''}">${body}</div>${full ? '' : navHtml()}`;
  const v = $('#view'); if (v && keep) v.scrollTop = sc;
  $$('.dstrip').forEach(s => { const on = $('.on', s); if (on) s.scrollLeft = on.offsetLeft - s.clientWidth / 2 + on.clientWidth / 2; });
  if (AFTER[cur.name]) AFTER[cur.name](cur.p);
}
const navHtml = () => `<div class="nav">${NAV.map(n => `<button class="${R.tab === n[0] ? 'on' : ''}" data-a="navgo" data-t="${n[0]}">${ic(n[1], 24)}<span>${n[2]}</span></button>`).join('')}</div>`;
A.navgo = el => nav(el.dataset.t);
A.go = el => {
  const [k, v] = el.dataset.to.split(':');
  if (k === 'tab') { if (v === 'day' && el.dataset.mode) R.dayMode = el.dataset.mode; nav(v); } else push(v, el.dataset.p ? JSON.parse(el.dataset.p) : {});
};
const gop = o => esc(JSON.stringify(o));
const hdr = (t, s, right) => `<div class="hd">${R.stack.length ? `<button class="ib" data-a="back">${ic('back')}</button>` : ''}<div class="hd-t"><h1>${t}</h1>${s ? `<p>${s}</p>` : ''}</div><div class="hd-r">${right || ''}</div></div>`;
const empty = (t, m, icon) => `<div class="empty"><div class="eico">${ic(icon || 'bars', 30)}</div><b>${esc(t)}</b><p>${esc(m || '')}</p></div>`;
const greet = () => { const h = new Date().getHours(); return h < 5 ? 'Good night' : h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : h < 21 ? 'Good evening' : 'Good night'; };
const avatar = (p, cls) => p.photo ? `<img class="av ${cls || ''}" src="${p.photo}" alt="">` : `<div class="av ini ${cls || ''}">${esc((p.name || 'A').trim().charAt(0).toUpperCase())}</div>`;
const ring = (pct, sz, inner, col) => { const r = 46, c = 2 * Math.PI * r; return `<div class="ring" style="width:${sz}px;height:${sz}px"><svg viewBox="0 0 110 110"><circle cx="55" cy="55" r="${r}" fill="none" stroke="rgba(128,128,128,.22)" stroke-width="9"/><circle cx="55" cy="55" r="${r}" fill="none" stroke="${col || 'var(--acc)'}" stroke-width="9" stroke-linecap="round" stroke-dasharray="${c}" stroke-dashoffset="${c * (1 - Math.min(100, pct) / 100)}" transform="rotate(-90 55 55)" style="transition:stroke-dashoffset .6s"/></svg><div class="ring-in">${inner || ''}</div></div>`; };

/* ---------- toast / sheets / dialogs ---------- */
let _tt;
function toast(m, bad) { const e = $('#toast'); e.textContent = m; e.className = 'show' + (bad ? ' bad' : ''); clearTimeout(_tt); _tt = setTimeout(() => e.className = '', 2300); }
function sheet(html) { $('#sheetRoot').innerHTML = `<div class="scrim" data-a="sheetclose"></div><div class="sheet">${html}</div>`; requestAnimationFrame(() => { const s = $('#sheetRoot .sheet'); if (s) s.classList.add('in'); }); }
function closeSheet() { $('#sheetRoot').innerHTML = ''; }
A.sheetclose = closeSheet;
let _cb = null;
function confirmBox(title, msg, fn, yes) { _cb = fn; $('#dlgRoot').innerHTML = `<div class="scrim"></div><div class="dlg"><b style="font-size:18px">${esc(title)}</b><p>${esc(msg)}</p><div class="dlg-b"><button class="btn" data-a="cbno">Cancel</button><button class="btn danger" data-a="cbyes">${yes || 'Delete'}</button></div></div>`; }
A.cbno = () => { $('#dlgRoot').innerHTML = ''; _cb = null; };
A.cbyes = () => { const f = _cb; A.cbno(); if (f) f(); };

/* ---------- form builders ---------- */
const F = {
  t: (l, n, v, ph, x) => `<label class="fl"><span>${l}</span><input class="inp" name="${n}" value="${esc(v || '')}" placeholder="${esc(ph || '')}" ${x || ''}></label>`,
  a: (l, n, v, ph) => `<label class="fl"><span>${l}</span><textarea class="inp" name="${n}" rows="3" placeholder="${esc(ph || '')}">${esc(v || '')}</textarea></label>`,
  d: (l, n, v) => `<label class="fl"><span>${l}</span><input class="inp" type="date" name="${n}" value="${v || ''}"></label>`,
  tm: (l, n, v) => `<label class="fl"><span>${l}</span><input class="inp" type="time" name="${n}" value="${v || ''}"></label>`,
  num: (l, n, v, ph, x) => `<label class="fl"><span>${l}</span><input class="inp" type="number" inputmode="numeric" name="${n}" value="${v == null ? '' : v}" placeholder="${esc(ph || '')}" ${x || ''}></label>`,
  s: (l, n, opts, v) => `<label class="fl"><span>${l}</span><select class="inp" name="${n}">${opts.map(o => { const a = Array.isArray(o) ? o : [o, o]; return `<option value="${esc(a[0])}" ${String(a[0]) === String(v) ? 'selected' : ''}>${esc(a[1])}</option>`; }).join('')}</select></label>`,
  col: (n, v, pal, label) => `<div class="fl"><span>${label || 'Color'}</span><div class="swatches">${(pal || PAL).map(c => `<i class="sw ${c.toLowerCase() === String(v).toLowerCase() ? 'on' : ''}" style="background:${c}" data-a="sw" data-c="${c}"></i>`).join('')}<input type="hidden" name="${n}" value="${v}"></div></div>`,
  days: (sel) => `<div class="fl"><span>Days</span><div class="dchks">${['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((l, i) => `<label class="dchk"><input type="checkbox" name="d${i}" ${(sel || []).includes(i) ? 'checked' : ''}><span>${l}</span></label>`).join('')}</div></div>`
};
A.sw = el => { const g = el.parentElement; $$('.sw', g).forEach(x => x.classList.remove('on')); el.classList.add('on'); $('input[type=hidden]', g).value = el.dataset.c; };
const formVals = root => { const o = {}; $$('[name]', root).forEach(e => { o[e.name] = e.type === 'checkbox' ? e.checked : e.value; }); return o; };
const pickDays = v => [0, 1, 2, 3, 4, 5, 6].filter(i => v['d' + i]);
function formSheet(title, body, onSave, o) {
  o = o || {};
  sheet(`<div class="sh-h"><b>${title}</b><button class="ib sm" data-a="sheetclose">${ic('x', 18)}</button></div><div id="frm">${body}<div class="err" id="ferr"></div></div><div class="sh-f">${o.onDel ? `<button class="ib red" id="fdel">${ic('trash', 20)}</button>` : ''}<button class="btn" data-a="sheetclose">Cancel</button><button class="btn pri" id="fsave">${o.saveLabel || 'Save'}</button></div>`);
  $('#fsave').onclick = function () {
    if (this.dataset.busy) return;
    const e = onSave(formVals($('#frm')));
    if (e) { $('#ferr').textContent = e; $('#ferr').scrollIntoView({ block: 'nearest' }); }
  };
  if (o.onDel) $('#fdel').onclick = o.onDel;
}
function infoSheet(title, rows, buttons) {
  sheet(`<div class="sh-h"><b>${esc(title)}</b><button class="ib sm" data-a="sheetclose">${ic('x', 18)}</button></div><div class="sh-b">${rows}</div><div class="sh-f">${buttons || '<button class="btn" data-a="sheetclose">Close</button>'}</div>`);
}
const kv = (k, v) => v === '' || v == null ? '' : `<div class="kv"><span>${k}</span><b>${v}</b></div>`;

/* ---------- sharing / files ---------- */
const safeName = n => String(n || 'file').replace(/[\\/:*?"<>|]/g, '_');
const blobToB64 = b => new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(String(r.result).split(',')[1]); r.onerror = no; r.readAsDataURL(b); });
async function shareBlob(blob, name) {
  name = safeName(name);
  try {
    if (isNative() && cap('Filesystem') && cap('Share')) {
      const w = await cap('Filesystem').writeFile({ path: name, data: await blobToB64(blob), directory: 'CACHE' });
      await cap('Share').share({ title: name, url: w.uri, dialogTitle: name });
    } else {
      const u = URL.createObjectURL(blob), a = document.createElement('a');
      a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 4000);
    }
  } catch (e) { if (!/cancel/i.test(String(e && e.message))) toast('Could not share or save this file', true); }
}
async function shareText(title, text) {
  try {
    if (isNative() && cap('Share')) await cap('Share').share({ title, text, dialogTitle: title });
    else if (navigator.share) await navigator.share({ title, text });
    else { await navigator.clipboard.writeText(text); toast('Copied to clipboard'); }
  } catch (e) { /* user cancelled */ }
}

/* ---------- task / deadline UI shared by Home and My Day ---------- */
function findOcc(id, occ) { return tasksOn(occ).find(x => x.id === id); }
A.tt = el => { const t = findOcc(el.dataset.id, el.dataset.occ); if (t) { toggleTask(t); toast(t.isDone ? 'Marked as not done' : 'Task completed'); render(true); scheduleSoon(); } };
A.td = el => { const t = findOcc(el.dataset.id, el.dataset.occ); if (t) taskDetail(t); };
function taskDetail(t) {
  const st = tstatus(t), rt = t.planId ? null : D.tasks.find(x => x.id === t.id);
  const rep = { none: 'Does not repeat', daily: 'Every day', weekly: 'Every week', custom: 'Custom days' }[t.repeat || 'none'];
  const hs = rt && rt.history ? rt.history.slice(-5).reverse().map(h => `<div class="kv"><span>${new Date(h.at).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}</span><b>${esc(h.act)}</b></div>`).join('') : '';
  infoSheet(t.title,
    `<div class="row" style="margin-bottom:8px"><span class="tag ${st === 'done' ? 'gr' : st === 'overdue' ? 'red' : st === 'active' ? '' : 'ye'}">${st.toUpperCase()}</span>${t.planId ? '<span class="tag">Generated study session</span>' : ''}</div>` +
    kv('Date', fmtD(t.occ, { weekday: 'long', month: 'long', day: 'numeric' })) + kv('Time', fmtT(t.start) + ' - ' + fmtT(t.end) + ' (' + dur(mins(t.end) - mins(t.start)) + ')') +
    kv('Subject', esc(t.subject)) + kv('Priority', t.planId ? '' : esc(t.priority)) + kv('Repeat', t.planId ? '' : rep) + kv('Reminder', t.planId ? '' : t.reminder === '' || t.reminder == null ? 'None' : t.reminder === '0' ? 'At start' : t.reminder + ' min before') +
    kv('Description', esc(t.desc)) + kv('Notes', esc(t.notes)) + (hs ? `<h3 style="margin:16px 0 4px;font-size:15px">History</h3>${hs}` : ''),
    `<button class="btn pri" data-a="tt" data-id="${t.id}" data-occ="${t.occ}" onclick="closeSheet()">${t.isDone ? 'Undo complete' : 'Mark complete'}</button>` +
    (t.planId ? `<button class="btn" onclick="closeSheet();push('exams')">Exam planner</button>` : `<button class="btn" data-a="edittask" data-id="${t.id}">Edit</button>`));
}
A.edittask = el => { const t = D.tasks.find(x => x.id === el.dataset.id); if (t) taskForm(t); };
A.addtask = () => taskForm(null);
function delTask(id) {
  const t = D.tasks.find(x => x.id === id);
  confirmBox('Delete task?', t && t.repeat !== 'none' ? 'This deletes the task and all of its repeats.' : 'This cannot be undone.', () => { D.tasks = D.tasks.filter(x => x.id !== id); save(); closeSheet(); toast('Task deleted'); render(true); scheduleSoon(); });
}
function taskForm(t) {
  const e = t || { date: R.sel || today(), start: '09:00', end: '10:00', priority: 'medium', color: '#08D9F2', repeat: 'none', repeatDays: [], reminder: '10' };
  formSheet(t ? 'Edit task' : 'New task',
    F.t('Title *', 'title', e.title, 'e.g. Complete assignments') + F.a('Description', 'desc', e.desc) + F.d('Date', 'date', e.date) +
    `<div class="two">${F.tm('Start', 'start', e.start)}${F.tm('End', 'end', e.end)}</div>` + F.num('Duration (minutes)', 'dur', mins(e.end) - mins(e.start), '', 'min="5"') +
    F.t('Subject / category', 'subject', e.subject, 'e.g. Psychology', 'list="subjl"') + `<datalist id="subjl">${subjectsList().map(s => `<option value="${esc(s)}">`).join('')}</datalist>` +
    F.s('Priority', 'priority', [['low', 'Low'], ['medium', 'Medium'], ['high', 'High']], e.priority) + F.col('color', e.color) +
    F.s('Reminder', 'reminder', [['', 'None'], ['0', 'At start time'], ['5', '5 min before'], ['10', '10 min before'], ['30', '30 min before'], ['60', '1 hour before']], e.reminder == null ? '' : e.reminder) +
    F.s('Repeat', 'repeat', [['none', 'Does not repeat'], ['daily', 'Every day'], ['weekly', 'Every week'], ['custom', 'Custom days']], e.repeat) + F.days(e.repeatDays) + F.a('Notes', 'notes', e.notes),
    v => {
      const title = v.title.trim();
      if (!title) return 'Title is required.';
      if (!validDate(v.date)) return 'Pick a valid date.';
      if (!validTime(v.start)) return 'Pick a start time.';
      let end = v.end;
      if (!validTime(end)) { const dm = +v.dur; if (dm > 0 && mins(v.start) + dm < 1440) end = hm(mins(v.start) + dm); else return 'Pick an end time.'; }
      if (mins(end) <= mins(v.start)) return 'End time must be later than start time.';
      const rd = pickDays(v); if (v.repeat === 'custom' && !rd.length) return 'Select at least one repeat day.';
      const o = { title, desc: v.desc.trim(), date: v.date, start: v.start, end, subject: v.subject.trim(), priority: v.priority, color: v.color, reminder: v.reminder, repeat: v.repeat, repeatDays: rd, notes: v.notes.trim() };
      if (t) { if (t.date !== o.date && o.repeat === 'none') t.doneDates = {}; Object.assign(t, o); hist(t, 'Edited'); }
      else D.tasks.push({ id: uid(), doneDates: {}, history: [{ at: Date.now(), act: 'Created' }], created: Date.now(), ...o });
      save(); closeSheet(); toast(t ? 'Task updated' : 'Task added'); render(true); scheduleSoon();
    }, { onDel: t ? () => delTask(t.id) : null });
}

const DCATS = ['Assignment', 'Exam', 'Project', 'Personal', 'Other'];
const DCOL = { high: '#F52C79', medium: '#FFD166', low: '#08D9F2' };
A.adddl = () => dlForm(null);
function dlForm(x) {
  const e = x || { date: R.sel || today(), time: '23:59', category: 'Assignment', priority: 'medium' };
  formSheet(x ? 'Edit deadline' : 'New deadline',
    F.t('Title *', 'title', e.title, 'e.g. Group presentation') + F.d('Due date', 'date', e.date) + F.tm('Due time', 'time', e.time) +
    F.s('Category', 'category', DCATS, e.category) + F.s('Priority', 'priority', [['low', 'Low'], ['medium', 'Medium'], ['high', 'High']], e.priority) + F.a('Description', 'desc', e.desc),
    v => {
      if (!v.title.trim()) return 'Title is required.';
      if (!validDate(v.date)) return 'Pick a valid due date.';
      if (!validTime(v.time)) return 'Pick a due time.';
      const o = { title: v.title.trim(), date: v.date, time: v.time, category: v.category, priority: v.priority, desc: v.desc.trim() };
      if (x) Object.assign(x, o); else D.deadlines.push({ id: uid(), done: false, ...o });
      save(); closeSheet(); toast(x ? 'Deadline updated' : 'Deadline added'); render(true); scheduleSoon();
    }, { onDel: x ? () => delDl(x.id) : null });
}
function delDl(id) { confirmBox('Delete deadline?', 'This cannot be undone.', () => { D.deadlines = D.deadlines.filter(x => x.id !== id); save(); closeSheet(); toast('Deadline deleted'); render(true); scheduleSoon(); }); }
A.dld = el => dlDetail(D.deadlines.find(x => x.id === el.dataset.id));
function dlDetail(x) {
  if (!x) return;
  const c = cdParts(x);
  infoSheet(x.title,
    `<div class="row" style="margin-bottom:8px"><span class="tag ${x.done ? 'gr' : c.over ? 'red' : 'ye'}">${x.done ? 'COMPLETED' : c.over ? 'OVERDUE' : 'UPCOMING'}</span><span class="tag">${esc(x.category)}</span></div>` +
    kv('Due', fmtD(x.date, { weekday: 'long', month: 'long', day: 'numeric' }) + ', ' + fmtT(x.time)) + kv(c.over ? 'Overdue by' : 'Time left', x.done ? '' : c.d + ' days, ' + c.h + ' hrs, ' + c.m + ' min') + kv('Priority', esc(x.priority)) + kv('Description', esc(x.desc)),
    `<button class="btn pri" data-a="dlok" data-id="${x.id}">${x.done ? 'Undo complete' : 'Mark complete'}</button><button class="btn" data-a="dledit" data-id="${x.id}">Edit</button>`);
}
A.dlok = el => { const x = D.deadlines.find(d => d.id === el.dataset.id); x.done = !x.done; save(); closeSheet(); toast(x.done ? 'Deadline completed' : 'Deadline reopened'); render(true); scheduleSoon(); };
A.dledit = el => dlForm(D.deadlines.find(d => d.id === el.dataset.id));

/* sticky notes */
A.addst = () => stForm(null);
A.edst = el => stForm(D.stickies.find(s => s.id === el.dataset.id));
function stForm(s) {
  const e = s || { color: '#20D6A5', pinned: false, text: '' };
  formSheet(s ? 'Edit sticky note' : 'New sticky note',
    F.a('Note', 'text', e.text, 'Return library book') + F.col('color', e.color) + `<label class="row" style="margin-bottom:10px"><input type="checkbox" name="pinned" ${e.pinned ? 'checked' : ''}> <span>Pin this note</span></label>`,
    v => {
      if (!v.text.trim()) return 'Write something first.';
      const o = { text: v.text.trim(), color: v.color, pinned: v.pinned, updated: Date.now() };
      if (s) Object.assign(s, o); else D.stickies.push({ id: uid(), created: Date.now(), ...o });
      save(); closeSheet(); toast(s ? 'Note updated' : 'Note added'); render(true);
    }, { onDel: s ? () => confirmBox('Delete note?', 'This cannot be undone.', () => { D.stickies = D.stickies.filter(x => x.id !== s.id); save(); closeSheet(); render(true); toast('Note deleted'); }) : null });
}
A.seld = el => { R.sel = el.dataset.d; render(true); };

/* global click delegation: any element with data-a runs A[name] */
document.addEventListener('click', e => {
  const el = e.target.closest('[data-a]'); if (!el) return;
  const f = A[el.dataset.a]; if (f) f(el, e);
});
