'use strict';
function dateStrip(kind) {
  const s = R.sel, t = today();
  let h = `<div class="dstrip ${kind}">`;
  for (let i = -10; i <= 20; i++) {
    const d = addDays(s, i), dt = pd(d);
    h += `<button class="dchip ${d === s ? 'on' : ''} ${d === t ? 'tod' : ''}" data-a="seld" data-d="${d}"><small>${dt.toLocaleDateString([], { weekday: 'short' })}</small><b>${dt.getDate()}</b></button>`;
  }
  return h + '</div>';
}
const stickySorted = () => D.stickies.slice().sort((a, b) => (b.pinned - a.pinned) || (b.updated || b.created) - (a.updated || a.created));
const stickyCard = s => `<button class="sticky ${s.pinned ? 'tint' : ''}" style="--c:${s.color}" data-a="edst" data-id="${s.id}"><span style="font-size:16px;line-height:1.35">${esc(s.text.length > 90 ? s.text.slice(0, 90) + '...' : s.text)}</span><small>${s.pinned ? ic('pin', 13) + ' ' : ''}${new Date(s.updated || s.created).toLocaleDateString([], { month: 'short', day: 'numeric' })}</small></button>`;
const dlCard = x => {
  const c = cdParts(x), col = DCOL[x.priority] || '#08D9F2';
  return `<div class="dl" style="--c:${col}" data-a="dld" data-id="${x.id}"><div class="grow"><b>${esc(x.title)}</b><small style="display:block;margin-top:6px">Due: ${fmtD(x.date)}, ${fmtT(x.time)}</small></div>
  <div class="cd ${c.over ? 'over' : ''}" data-cdid="${x.id}"><div class="cdn">${cdTxt(c)}</div><div class="cdl">${c.over ? 'OVERDUE' : 'DAYS HRS MIN'}</div></div></div>`;
};

SCREENS.home = () => {
  const d = R.sel, s = dayStats(d), p = D.profile, wk = weekScores(d), n = unread();
  const sc = wk.filter(x => x.sc != null), avg = sc.length ? Math.round(sc.reduce((a, b) => a + b.sc, 0) / sc.length) : null;
  const best = sc.length ? sc.reduce((a, b) => b.sc > a.sc ? b : a) : null;
  const dls = D.deadlines.filter(x => !x.done).sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
  const stat = (to, icon, col, val, lab, p2) => `<button class="stat" style="--c:${col}" data-a="go" data-to="${to}" ${p2 || ''}><i>${ic(icon, 18)}</i><span><b>${val}</b><small>${lab}</small></span></button>`;
  return `
  <div class="top"><div class="who" data-a="go" data-to="tab:profile">${avatar(p)}<div style="min-width:0"><small>${greet()},</small><h2>${esc(first(p.name))}</h2></div></div>
    <div class="row"><button class="ib big" data-a="go" data-to="push:search">${ic('search')}</button><button class="ib big rel" data-a="go" data-to="push:notifs">${ic('chat')}${n ? `<i class="badge">${n > 99 ? '99+' : n}</i>` : ''}</button></div></div>
  ${dateStrip('pill')}
  <div class="dgrid">
    <button class="card dp" data-a="go" data-to="push:analytics"><b class="mut" style="font-size:15px">Daily Progress</b>${ring(s.pct, 112, `<span style="color:var(--acc)">${ic('drop', 20)}</span><span>${s.pct}%</span>`)}<small>${s.total ? s.done + ' of ' + s.total + ' tasks done' : 'No tasks yet'}</small></button>
    <div class="card stats">
      ${stat('push:analytics', 'brief', '#FF8A3D', dur(s.workload), 'Workload')}
      ${stat('tab:day', 'list', '#F52C79', s.pending, 'Pending')}
      ${stat('tab:focus', 'pulse', '#20D6A5', dur(s.focus), 'Focus')}
      ${stat('tab:focus', 'clock', '#8B36F5', dur(s.sched), 'Schedule')}
      ${stat('tab:day', 'bolt', '#FFD166', maxStreak(), 'Habit Streak', 'data-mode="habits"')}
      ${stat('push:deadlines', 'target', '#F52C79', s.due, 'Due Today')}
    </div>
  </div>
  <div class="card" style="margin-top:14px"><div class="row between"><div><h3>Productivity Pulse</h3><div style="margin-top:6px;font-size:14px"><b style="color:var(--acc)">${avg == null ? 'No data yet' : avg + '% Avg'}</b>${best ? `<span class="mut"> • Best: ${pd(best.d).toLocaleDateString([], { weekday: 'short' })}</span>` : ''}</div></div><button class="ib" data-a="go" data-to="push:analytics">${ic('bars', 20)}</button></div>
    <div class="pulse">${wk.map(x => { const f = x.sc == null ? 0 : Math.ceil(x.sc / 20); return `<button class="pcol ${x.d === d ? 'on' : ''}" data-a="pday" data-d="${x.d}"><b>${x.sc == null ? '-' : x.sc}</b>${[5, 4, 3, 2, 1].map(i => `<i class="pblk ${f >= i ? 'f' : ''}"></i>`).join('')}<span>${pd(x.d).toLocaleDateString([], { weekday: 'short' })}</span></button>`; }).join('')}</div>
    ${sc.length ? '' : '<p class="mut" style="font-size:13px;margin-top:12px">Add tasks, habits or focus sessions and your pulse fills in.</p>'}</div>
  <button class="ai" data-a="go" data-to="push:exams"><span>${ic('cpu', 44)}</span><span class="grow"><b>AI Exam Planner</b><small>Generate auto-timelines and matrices for your exams.</small></span><span>${ic('chev', 30)}</span></button>
  <div class="sec"><h3>Today's Planner</h3><button class="ib" data-a="addtask">${ic('plus', 20)}</button></div>
  ${s.ts.length ? `<div class="hs">${s.ts.map(t => { const st = tstatus(t), c = t.color || '#08D9F2'; return `<div class="pcard ${st === 'done' ? 'done' : ''}" style="--c:${c}" data-a="td" data-id="${t.id}" data-occ="${t.occ}"><div class="row between" style="align-items:flex-start"><b>${esc(t.title)}</b><button class="cbx ${st === 'done' ? 'on' : ''}" style="--c:${c}" data-a="tt" data-id="${t.id}" data-occ="${t.occ}">${st === 'done' ? ic('check', 16) : ''}</button></div><span class="chip">${ic('clock', 14)} ${fmtT(t.start)} - ${fmtT(t.end)}</span></div>`; }).join('')}</div>` : empty('Nothing planned', 'Tap + to plan this day.', 'cal')}
  <div class="sec"><h3><span style="color:var(--pk)">${ic('alert', 22)}</span> Deadlines</h3><div class="row"><button class="link" data-a="go" data-to="push:deadlines">All</button><button class="ib" data-a="adddl">${ic('plus', 20)}</button></div></div>
  ${dls.length ? `<div class="hs">${dls.slice(0, 10).map(dlCard).join('')}</div>` : empty('No open deadlines', 'Add one to see a live countdown.', 'target')}
  <div class="sec"><h3>Sticky Notes</h3><div class="row"><button class="link" data-a="go" data-to="push:stickies">All</button><button class="ib" data-a="addst">${ic('plus', 20)}</button></div></div>
  ${D.stickies.length ? `<div class="hs">${stickySorted().slice(0, 12).map(stickyCard).join('')}</div>` : empty('No sticky notes', 'Jot down quick reminders.', 'edit')}`;
};

A.pday = el => {
  const d = el.dataset.d, s = dayStats(d), sc = score(d);
  infoSheet(fmtD(d, { weekday: 'long', month: 'long', day: 'numeric' }),
    kv('Productivity', sc == null ? 'No activity recorded' : sc + '%') + kv('Tasks completed', s.done + ' of ' + s.total) + kv('Workload', dur(s.workload)) + kv('Focus time', dur(s.focus) + (s.sched ? ' of ' + dur(s.sched) + ' scheduled' : '')) + kv('Habits done', s.hTotal ? s.hDone + ' of ' + s.hTotal : '') + kv('Deadlines due', s.due),
    `<button class="btn" data-a="sheetclose">Close</button><button class="btn pri" onclick="R.sel='${d}';closeSheet();nav('day')">Open day</button>`);
};

SCREENS.deadlines = () => {
  const all = D.deadlines.slice().sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
  const open = all.filter(x => !x.done), done = all.filter(x => x.done);
  const row = x => { const c = cdParts(x); return `<button class="li" style="--c:${DCOL[x.priority]}" data-a="dld" data-id="${x.id}"><div class="grow"><b class="${x.done ? 'strike' : ''}">${esc(x.title)}</b><small>${esc(x.category)} · ${fmtD(x.date)}, ${fmtT(x.time)}</small></div>${x.done ? '<span class="tag gr">Done</span>' : c.over ? '<span class="tag red">Overdue</span>' : `<span class="tag ye" data-cdtag="${x.id}">${c.d}d ${c.h}h</span>`}</button>`; };
  return hdr('Deadlines', 'Track what is due', `<button class="ib big" data-a="adddl">${ic('plus')}</button>`) + (open.length ? open.map(row).join('') : empty('No open deadlines', 'Tap + to add one.', 'target')) + (done.length ? `<div class="cap">COMPLETED</div>${done.map(row).join('')}` : '');
};

SCREENS.stickies = () => `${hdr('Sticky Notes', 'Quick reminders', `<button class="ib big" data-a="addst">${ic('plus')}</button>`)}<div class="search">${ic('search')}<input id="sq" placeholder="Search sticky notes" value="${esc(R.sq || '')}"></div><div id="sres">${stRes(R.sq || '')}</div>`;
function stRes(q) {
  q = q.trim().toLowerCase(); const l = stickySorted().filter(s => !q || s.text.toLowerCase().includes(q));
  return l.length ? `<div class="fgrid">${l.map(s => `<button class="fcard" style="--c:${s.color}" data-a="edst" data-id="${s.id}"><span style="line-height:1.4">${esc(s.text)}</span><small>${s.pinned ? ic('pin', 13) + ' ' : ''}${new Date(s.updated || s.created).toLocaleDateString([], { month: 'short', day: 'numeric' })}</small></button>`).join('')}</div>` : empty(q ? 'No matches' : 'No sticky notes', q ? 'Try different words.' : 'Tap + to add one.', 'edit');
}
