// Runs in CI after `npx cap add android`. Best-effort patches; never fails the build.
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const res = path.join(root, 'android', 'app', 'src', 'main', 'res');
const manifestPath = path.join(root, 'android', 'app', 'src', 'main', 'AndroidManifest.xml');

function safe(label, fn) { try { fn(); console.log('OK   ' + label); } catch (e) { console.log('SKIP ' + label + ': ' + e.message); } }

safe('permissions', () => {
  let m = fs.readFileSync(manifestPath, 'utf8');
  const perms = [
    'android.permission.POST_NOTIFICATIONS',
    'android.permission.VIBRATE',
    'android.permission.RECEIVE_BOOT_COMPLETED',
    'android.permission.SCHEDULE_EXACT_ALARM',
    'android.permission.USE_EXACT_ALARM'
  ];
  const add = perms.filter(p => !m.includes(p)).map(p => '    <uses-permission android:name="' + p + '" />').join('\n');
  if (add) m = m.replace('</manifest>', add + '\n</manifest>');
  m = m.replace(/android:label="[^"]*"/, 'android:label="AARZOO"');
  fs.writeFileSync(manifestPath, m);
});

safe('icons', () => {
  const src = path.join(root, 'resources');
  for (const d of fs.readdirSync(res).filter(x => x.startsWith('mipmap-') && !x.includes('anydpi'))) {
    for (const [from, to] of [['icon-foreground.png', 'ic_launcher_foreground.png'], ['icon.png', 'ic_launcher.png'], ['icon.png', 'ic_launcher_round.png']]) {
      fs.copyFileSync(path.join(src, from), path.join(res, d, to));
    }
  }
  const bg = path.join(res, 'values', 'ic_launcher_background.xml');
  fs.writeFileSync(bg, '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#000000</color>\n</resources>\n');
});

safe('dark window background', () => {
  const p = path.join(res, 'values', 'styles.xml');
  let s = fs.readFileSync(p, 'utf8');
  if (!s.includes('android:windowBackground')) {
    s = s.replace(/(<style name="AppTheme\.NoActionBar"[^>]*>)/, '$1\n        <item name="android:windowBackground">@android:color/black</item>\n        <item name="android:statusBarColor">@android:color/black</item>\n        <item name="android:navigationBarColor">@android:color/black</item>');
  }
  fs.writeFileSync(p, s);
});
